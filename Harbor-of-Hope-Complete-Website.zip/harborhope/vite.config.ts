import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import path from "node:path";
import { defineConfig, type Plugin, type ViteDevServer } from "vite";

function publicPageRendering(): Plugin {
  let server: ViteDevServer | undefined;
  return {
    name: "harbor-public-page-rendering",
    configureServer(vite) {
      server = vite;
      vite.middlewares.use(async (req, res, next) => {
        if (req.method !== "GET" || !req.headers.accept?.includes("text/html"))
          return next();
        const url = new URL(req.url || "/", "http://localhost");
        if (
          url.pathname.includes(".") ||
          url.pathname.startsWith("/@") ||
          url.pathname.startsWith("/api/") ||
          url.pathname.startsWith("/manus-storage/")
        )
          return next();
        try {
          const entry = await vite.ssrLoadModule("/src/entry-server.tsx");
          const result = entry.render(url.pathname);
          if (result.status === 404) {
            res.statusCode = 404;
            res.setHeader("Content-Type", "text/html; charset=utf-8");
            res.end(
              `<!doctype html><html lang="en"><head><meta name="viewport" content="width=device-width,initial-scale=1"/>${result.head}</head><body><h1>Page not found</h1><p><a href="/">Return to Harbor of Hope</a></p></body></html>`
            );
            return;
          }
          next();
        } catch (error) {
          next(error as Error);
        }
      });
    },
    transformIndexHtml: {
      order: "post",
      async handler(html, context) {
        if (!server || !context.server) return html;
        const entry = await server.ssrLoadModule("/src/entry-server.tsx");
        const pathname = new URL(
          context.originalUrl || context.path,
          "http://localhost"
        ).pathname;
        return entry.fillDocument(html, pathname).html;
      },
    },
  };
}

export default defineConfig({
  plugins: [react(), tailwindcss(), publicPageRendering()],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client/src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets"),
    },
  },
  envDir: path.resolve(import.meta.dirname),
  root: path.resolve(import.meta.dirname, "client"),
  publicDir: path.resolve(import.meta.dirname, "client/public"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true,
  },
  server: {
    host: true,
    // Vite's safe localhost/IP defaults apply. Add an explicit hostname here
    // only if you deliberately expose a development server through that host.
    fs: { strict: true, deny: ["**/.*"] },
  },
});
