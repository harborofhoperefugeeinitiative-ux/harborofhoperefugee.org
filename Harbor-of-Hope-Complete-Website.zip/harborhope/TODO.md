# Harbor of Hope — approved website outcomes

- [x] **Homepage:** Create a professional, modern, welcoming, and user-friendly website. Present the tagline “Care. Protect. Empower. Together, We Bring Hope.”, mission, vision, Uganda focus, refugee-led identity, and careful calls to learn, partner, support, or make an inquiry. Use the supplied organization profile as the main reference.
- [x] **About:** Cover the organization's story, community-led and rights-based approach, core values, governance, registration number 80044148475426, accountability commitments, safeguarding, confidentiality, and responsible resource management.
- [x] **Programs:** Present all eight thematic programs with concise explanations and pathways to explore each area of work. Assistance depends on resources and capacity; do not promise immediate assistance.
- [x] **Why it matters and intended impact:** Explain needs, objectives, and aspirational outcomes without unverified claims, invented statistics, testimonials, or measured results.
- [x] **Partnerships and support:** Include donors, foundations, embassies, humanitarian actors, refugee-led groups, healthcare and human rights organizations, volunteers, and technical partners. Ground partnerships in mutual respect, transparency, dignity, confidentiality, and safeguarding.
- [x] **Help:** Provide safe support information, realistic expectations, and context-sensitive emergency guidance. Never expose shelter locations or sensitive case information.
- [x] **Contact and support inquiries:** Collect only essential information, explain use, discourage sensitive details, and include clear consent and safety messaging. Prepare an email draft for the visitor to review and send through their own email app; provide a copyable fallback. Explicitly state that preparing a draft does not send it. Do not store inquiry details on the website or use session replay.
- [x] **Contact details:** Include P. O. Box 209824, Kampala, Uganda; harborofhoperefugeeinitiative@gmail.com; telephone / WhatsApp +256 790 448 018. Withhold private shelter addresses and sensitive operational locations.
- [x] **Design and accessibility:** Responsive, accessible navigation and readable content; dignified imagery; no unsafe case material. As explicitly approved in the October 9 follow-up, use the supplied activity photos after the organization confirmed usage permission, consent, and safety clearance. Captions do not infer identities, dates, exact locations, beneficiary status, or formal partner affiliations. Include mobile navigation, keyboard focus, reduced-motion behavior, privacy guidance, and a clearly explained quick-exit function.
- [x] **Delivery:** Meaningful initial HTML and per-page metadata; working routes and profile download; checked source and production build; saved project source and working preview.

## Completion evidence

The seven public pages render complete initial HTML with distinct metadata. TypeScript checks pass; all 19 automated tests pass; the static production build renders all seven routes. The route manifest matches the page set, and missing development routes return HTTP 404. The downloadable Word profile was verified as a valid Word document. The initial independent read-only review found no blockers; its two minor findings were corrected. Publication is not enabled: this handoff is a preview, not a public launch. Contact forms prepare user-reviewed email drafts; payments and automated alerts are not enabled.

## Supplied images — October 2026 update

On October 9, the organization explicitly confirmed: “All photos are cleared for use and show our own activities, except the flags image.” This confirmation followed the question covering usage permission, participant consent for this website, and safety review. It resolves the previous photo-clearance blocker. No additional consent or identity information is collected.

- [x] Image 1: Homepage community hero, without text or badges over faces.
- [x] Image 2: Partnerships — community connections.
- [x] Image 3: Programs — community solidarity beside protection information, without identifying a shelter or claiming delivered accommodation.
- [x] Image 4: About — community solidarity.
- [x] Image 5: Programs — community outreach and participation.
- [x] Image 6: About — community connections.
- [x] Image 7: Partnerships — discussion and exchange.
- [x] Image 8: Homepage Why This Work Matters — Uganda and Progress Pride flags.
- [x] Image 9: Programs — human rights advocacy.
- [x] Preserve full compositions and original uploads, optimize website copies, omit EXIF/XMP metadata, add descriptive alt text and neutral captions, and distinguish supplied activity photos from illustrative artwork. Visible third-party signs or logos do not imply a formal partnership or endorsement.

## Official organization logo — October 9 update

- [x] Replace the temporary harbor mark with the supplied official artwork from `LogoofHarbor1..pdf` in the shared header, footer, and desktop partnership banner. Preserve its original colors and proportions. Display the complete official logo with its original lettering on the About page.
- [x] Use official-logo PNG and ICO browser icons, replace the previous social-sharing image, provide descriptive sharing-image alt text, and set the project logo to the durable HTTPS official-mark URL. Remove the unused temporary SVG logo.
- [x] Keep the original PDF unchanged. Website extracts omit only the surrounding poster layout; the complete logo artwork and lettering remain intact and were visually verified.

TypeScript checks and the production build pass; all 20 automated tests pass. The built pages reference the official logo assets and browser icons. This update does not publish the website or alter its inquiry handling.

## Professional matching-color refinement

- [x] Use the official logo's navy, cyan, and magenta in a cohesive, restrained palette across every public page. Replace the previous plum, sage, and peach treatments with brand-related tints; use high-contrast text and actions.
- [x] Improve the layout, typography, spacing, navigation, cards, photo frames, form controls, footer, and responsive presentation so the website looks professional, welcoming, and easy to read.
- [x] Preserve the official artwork, all nine supplied images, original organizational facts, capacity qualifications, safe email-draft inquiry workflow, and privacy commitments. Do not publish the website as part of this visual refinement.

The navy/cyan/magenta refinement is documented in `plan.md`. All legacy palette token references were removed, and every CSS custom-property reference resolves. The production build and TypeScript checks pass; all 24 automated tests pass, including text contrast, visible field boundaries, photo-composition preservation, and official branding checks. The public preview serves the refined stylesheet and navy theme color. An independent read-only review found no confirmed blockers in shared styling, responsive rules, image treatment, or behavior. Publication remains disabled.

## Organization identity and bespoke presentation correction

These instructions supersede earlier profile-download and community-led wording requirements.

- [x] Remove the organization profile document download from the website, including About and Partnerships, and remove public source-document references. Preserve the user's original attachment and use its facts internally; do not claim physical deletion of the managed storage object.
- [x] Describe Harbor of Hope as a refugee-led organization, not a community-led initiative. Correct the header, homepage, About approach, shared footer and partnership copy, program descriptions, and search metadata. Community outreach and feedback can remain part of the organization's work; they do not define its leadership.
- [x] Replace the white-heavy background with a clear navy hero and page-intro treatment over a visibly slate-blue canvas and tinted surfaces. Produce a distinctive, professional, restrained design using the official logo and authentic supplied activity photographs rather than generic AI-looking artwork, repeated slogan headlines, and pastel card grids. Do not misrepresent how the website was made.
- [x] Remove the remaining generated botanical illustration and update the image disclosure accordingly. Preserve all nine supplied photographs, the official logo, safety messaging, capacity qualifications, and safe email-draft forms. Keep this as a preview, not a publication.

TypeScript checks, the seven-page static build, and all 27 automated tests pass. Each public preview page was verified as HTTP 200 with the corrected organizational identity and no profile link, public source-document reference, community-led claim, or generated-artwork reference. The preview serves the slate-blue color tokens and revised navy/editorial stylesheet. All photo placements, official branding, safe inquiry behavior, and capacity qualifications remain covered by regression tests. An independent integrated read-only review found no confirmed blockers or minor defects. The original supplied document is unchanged; only website download access points and public references were removed, not the underlying managed storage bytes. Publication remains disabled.

## Supplied partner and donor logos

- [x] Add the four organizations identified by the user as partners and donors: Human Rights Awareness and Promotion Forum (HRAPF), Universal Coalition of Affirming Africans Uganda (UCAA-UG), Rainbow Railroad, and The International Pride Centre. Show all four supplied logos and readable organization names under “Our partners & donors” on the homepage and Partnerships page.
- [x] Preserve original colors, lettering, complete image proportions, and supplied source files; use dedicated durable website assets rather than replacing any existing activity photographs. Match the navy and slate-blue design with accessible image descriptions and responsive layout. Do not invent individual donor/partner categories, grant amounts, dates, testimonials, or external links. Keep all existing content-removal, safety, inquiry, and preview-only requirements intact.

All four logos were converted losslessly with exact RGB pixel and dimension preservation and uploaded as distinct managed assets. The acknowledgment sections include all four names and logos in the initial HTML on both pages. The privacy wording distinguishes the user-confirmed named organizations from incidental signs in activity photographs. TypeScript checks, all 31 automated tests, and the seven-page static build pass. Both updated public-preview pages and all four logo downloads were verified as HTTP 200; the seven-route manifest remains unchanged. The original activity photo paths, official Harbor of Hope logo, document-removal requirements, refugee-led identity, and safe inquiry behavior remain intact. Publication remains disabled.

## Reference homepage and photo-led pages

These instructions supersede the previous plain-sans hero and numbered editorial treatments.

- [x] Make Home and About Us explicit independent navigable pages at `/` and `/about`; preserve their existing substantive content and all other working pages. Match the shared reference's full-width photograph, dark overlay, serif white/gold headline “Safety is a beginning. Hope is a practice.”, coral and outlined actions, and navigation across the picture. Use the same underlying cleared photo 4, not a screenshot with unclickable controls. Keep refugee-led organization wording rather than restore the superseded community-led description.
- [x] Give every public page a prominent picture-led hero using cleared supplied activity photos, descriptive alt text, readable responsive text, and working navigation. Retain mobile navigation, Quick exit, official identity, all nine activity/context photographs, four partner logos, non-white content surfaces, privacy/capacity guidance, and the safe email-draft inquiry behavior. Do not invent a checkout, measured impact, or testimonial. Donate links to the existing support-discussion section; Our Impact links to the existing intended-impact section.
- [x] Remove the decorative numbering throughout Home, About approaches and values, program jump links/panels/kickers, and support steps, without hiding meaningful registration, contact details, dates, or program facts. Keep page metadata and route-manifest labels accurate; leave publication disabled.

The reference-style Home hero is recreated with real serif text, original cleared photo 4, white/gold headline, midnight gradient, live coral/outlined actions, and overlaid navigation. All seven pages have an explicit supplied hero picture; mobile uses a full-composition image band below readable text. Home and About Us are labeled as separate pages in desktop/mobile navigation, footer, and route manifest. Decorative numbers are removed from rendered page markup, while registration and phone details remain. TypeScript checks, all 35 automated tests, and the seven-page static build pass. Public-preview requests verified all seven photo-led pages as HTTP 200, with the requested headline and photograph on Home, the About Us heading, corrected refugee-led identity, no decorative numbers, no profile download, and the synchronized route manifest. The reference-led CSS is available in Preview. An independent source-level integrated review found no confirmed blockers; this review did not claim screenshot or browser validation. All activity/context images, partner/donor logos, official branding, safety/capacity messaging, and safe inquiry behavior remain present. Publication remains disabled.

## Spotfund donation destination

- [x] Connect donation links to the exact user-provided `http://spot.fund/d8qhqnrsc` from desktop and mobile navigation, the Partnerships support card, the shared partnership banner, and footer. Clearly identify Spotfund as an external donation service, open links safely in a new tab, keep the contact option for other support, and do not collect or process payments on this website. Preserve the existing reference-led design, page photos, partner acknowledgments, safe forms, and preview-only status.

The shared DonationLink uses the exact supplied URL, safe new-tab attributes, and an accessible Spotfund destination label. The Partnerships card and privacy page explain external donation processing; an in-kind/other-support contact option remains available. All 38 automated tests and TypeScript checks pass; the static build renders all seven pages. The public preview was checked on all seven routes for the correct URL and safe link attributes. The supplied destination fetched a Spotfund page, but no campaign details, fees, or tax status are asserted. No payment was made or financial information entered. Publication remains disabled.

## Supplied Our Story

- [x] Add the full supplied organization story to About Us, including “Born from the Need for Safety. Built on Hope.”, founding in 2024, opening narrative, Why We Began, What We Stand For, Our Journey Is Not Over, Our Hope for Tomorrow, closing message, and tagline. Keep it readable and responsive within the non-white design with unnumbered chapter links. Preserve the previously corrected refugee-led organization identity and participation meaning, add a homepage story link and Founded 2024 at a glance, and retain all existing content, photographs, official logo, partner recognition, Spotfund links, safety guidance, and working pages. Do not invent history, individual stories, or measured impact; leave publication disabled.

The full story is presented on About Us with five opening paragraphs and four chapters containing 5, 5, 3, and 5 paragraphs. The two community-led phrases are aligned with the user's earlier refugee-led organization correction; all other supplied narrative paragraphs are retained. The story includes the founding year, subtitle, closing message, and tagline. A source comparison and the live public-preview response confirm every narrative paragraph is present. Chapter anchors, homepage story link, existing hero photograph, and Spotfund link were verified. The story uses readable serif chapter headings, unnumbered chapter navigation, and responsive slate-blue surfaces. TypeScript checks, all 41 automated tests, and the seven-page static build pass. All previously required organization content, photos, official branding, safeguarding guidance, and external-donation behavior remain intact. Publication remains disabled.

## Remove visible hero photograph label

- [x] Remove “Harbor of Hope activity photograph · shared with permission” from all page heroes. Keep the photographs, alt text, layout, other captions, Our Story, donation links, and existing privacy guidance unchanged. Leave publication disabled.

Removed the label's markup from the shared PhotoHero component, not just visually hidden it. All seven public-preview pages were verified to omit the label and retain their hero images. TypeScript checks, all 41 automated tests, and the seven-page static build pass. No other page content or photo styling changed.

## October 10 registration-number removal and grounded story

- [x] Remove the registration number from every public page and the browser-delivered organization data, including the shared footer and About Us. Keep the source documents, other governance information, contact details, and all existing functions unchanged.
- [x] Remove “Imagine” from Our Story and replace the hypothetical passage with a grounded description of LGBTQ+ refugees' real-life experiences, without inventing personal cases. Retain the rest of the story and current design. Save and verify the changes without automatically republishing.

The shared footer and About Us no longer show the registration number, and its field has been removed from client organization data. Verified absence from every generated HTML, JavaScript, and JSON file and all seven Preview pages. The story now begins the corrected passage “Many LGBTQ+ refugees leave their homes in search of safety, separated from loved ones and the lives they knew.” The rest of the story and design are unchanged. TypeScript, all 42 tests, and the seven-page production build pass; preview checks confirm working contact and donation links. Automatic publication remains disabled; these edits do not replace the live version until republished.

## Screenshot-based content removal

- [x] Remove the specific Get Support information shown in the supplied screenshots: immediate-danger box, safe-channel step, inquiry explanation, WhatsApp explanatory note, and adjacent default safety callout. Retain the WhatsApp contact button, inquiry form, remaining support steps, FAQs, and other page content.
- [x] Remove the About Us development-status paragraph, commitments checklist, and its local Raise a concern button shown in the screenshot. Keep the governance introduction, accountability anchor, footer links, and privacy content. Reflow remaining content without empty columns; preserve the registration removal and grounded story. Save and verify in Preview without automatically republishing.

Both affected Preview pages were checked as HTTP 200. The screenshot-specific text is removed; the WhatsApp contact button, email-draft form, two remaining support steps, FAQ, governance introduction, and privacy content remain. Governance uses a readable single column; support steps use two columns and stack on mobile. Registration-number removal and the grounded story remain verified. TypeScript, all 45 tests, and the seven-page static build pass. No screenshots were reopened. The live site has not been republished with these edits.

## Remove photo credits and WhatsApp contact channel

- [x] Remove “Photo supplied by Harbor of Hope” and the equivalent “Image supplied by Harbor of Hope” label from every picture caption. Preserve the actual images, descriptive captions, accessible alt text, and privacy consent description.
- [x] Remove WhatsApp contact buttons and links from Contact and Get Support, remove its central URL, and update metadata, FAQ, privacy and inquiry copy so the website no longer advertises WhatsApp as a channel. Preserve telephone, email, email-draft forms, donation links, design, and all earlier corrections. Save and verify in Preview without automatically republishing.

Supplier credit labels are removed from shared activity captions and the homepage flags caption. WhatsApp controls, URL, and public mentions are removed, including contact metadata and draft-result copy. All 48 tests, TypeScript checks and the seven-page static build pass. Every Preview route responds HTTP 200 with no supplier labels or WhatsApp references and retains email, telephone and Spotfund links. Built HTML, JavaScript and JSON were also checked for the removed text. Photos, descriptive captions, alt text and consent information remain intact. The live website has not been republished with these corrections.

## Reference-style Contact Us form

- [x] Match the supplied contactus.jpeg form with Name * and side-by-side First/Last inputs, Email *, Objectif subject input, large Comment or Message textarea and blue Submit button inside a spacious white panel with dark labels and thin gray borders. Stack name fields on small phones; retain Contact Us hero, email, telephone, postal details and the surrounding site design.
- [x] Require non-blank first/last name and valid email; allow aliases, bound every input, keep optional subject/comment, retain topic/program query prefills and safely encoded email drafts. Submit must accurately explain that it prepares a draft, not sends a message; provide review/open-email/copy/clear controls. Keep the Get Support form unchanged and update privacy wording for the distinct name requirements. Preserve preceding removals and donation controls. Save and verify without automatically republishing.

Contact Us uses a dedicated reference variant with matching labels, blank inputs, gray borders, white panel, large textarea and blue Submit action. The button has 5.57:1 contrast with white text. Names are required but aliases are accepted; the optional subject remains freely editable and resets to empty. Existing topic/program prefills and encoded email draft review/copy/open/clear controls are preserved. Get Support retains its original optional-alias and consent form. Privacy wording distinguishes both forms. TypeScript checks, all 52 tests and the seven-page static build pass; Contact, Support and Privacy Preview responses were checked. No screenshot was reopened or direct email delivery claimed. Automatic publication remains disabled.

## Postal-only label removal

- [x] Remove “Postal address only” from every page footer and the Contact Us address label. Keep the actual postal address, other contact information, form, and all prior corrections unchanged. Save in Preview without automatically republishing.

Removed the footer note and unused line break; the contact heading now reads “POSTAL ADDRESS.” All seven Preview pages were verified to omit the requested phrase and retain the exact address. TypeScript, all 53 tests and the seven-page build pass. The reference Contact Us form and all previous corrections remain intact. The live site has not been republished.

## Direct contact-message email delivery

- [ ] Replace the Contact Us email-draft submission with server-side delivery to harborofhoperefugeeinitiative@gmail.com without requiring visitors to open an email app. Retain the reference form design, required names/email, optional subject/message, topic/program context, and prior removals. Keep sender credentials server-only, validate and bound inputs, keep the recipient fixed, provide spam protection and accurate pending/success/failure messages, and update privacy disclosures. Validate the email transport and delivery with a clearly labeled test message before claiming working direct delivery. No guarantee of inbox placement. Leave existing behavior intact until credentials are securely supplied and integration is ready.

The previous publication request wdo_4b91f45b851cb4c27ca32f2c is authoritatively cancelled. No direct email delivery is configured yet. The current published-site configuration is static with no server capability and no email secrets. A Gmail App Password is required for the proposed server SMTP transport, and must be supplied through protected input, never in chat or source code.

### Direct-delivery setup status

The user approved one-way server enablement and one labeled test email on October 10. Server is enabled, database remains disabled, and the platform now selects Dockerfile deployment with /api/health. Nodemailer and its types are installed. Gmail SMTP connection reached authentication but returned EAUTH / SMTP 535. No test message was sent, no contact form direct-delivery behavior was activated, and publication remains on hold. A replacement dedicated Google App Password for the exact organization account is requested through secure input. Continue only after credential authentication succeeds; do not treat current sending behavior as complete.

The replacement Gmail credential (declaration revision 2, all environments) was synchronized and tested once. Gmail again returned EAUTH / SMTP 535. No email was sent. Do not repeat credential requests without resolving account/App Password setup with the user. Backend enablement remains approved and enabled; form changes, email-delivery claims, checkpointing this unfinished integration and publication remain on hold. Existing frontend forms are unchanged.

## Inbox-activated Contact Us service

- [ ] Route Contact Us submissions to harborofhoperefugeeinitiative@gmail.com through FormSubmit, preserving screenshot fields/layout, topic/program context, input validation and previous corrections. Preserve Get Support email drafts. No visitor email app or Gmail App Password required. State that FormSubmit processes submissions and retains an archive for 30 days; show honest service-acceptance/errors rather than guaranteed inbox delivery. Trigger one labeled activation/test submission and have the owner activate through their inbox before claiming live delivery. Remove unused Gmail credential/dependencies. Server capability remains enabled; preserve pre-rendered pages in deploy configuration. Leave publication pending until activation and user review.

### FormSubmit integration evidence

Contact Us now has a dedicated native POST form to https://formsubmit.co/harborofhoperefugeeinitiative@gmail.com, preserving first/last names, email, optional subject/message and reference styling. It keeps FormSubmit's default reCAPTCHA and a hidden honeypot; no cc, autoresponse or attachments. Native form submission also works without JavaScript. Contact and privacy disclosures explain third-party processing and 30-day archive retention. Get Support retains its draft workflow. The unused Gmail secret was withdrawn and nodemailer dependencies removed. The enabled server remains; Dockerfile now builds pre-rendered pages, and server serving is corrected to return each actual page instead of the homepage fallback. All 53 tests and TypeScript checks pass. Static and server builds pass; local production health and Home/About/Contact/Privacy serving were verified. One labeled browser activation/test submission is in progress; delivery and activation are NOT confirmed yet. Publication is not submitted.

The read-only integration review found no confirmed implementation or production-serving defects; “Objectif” is intentionally retained from the user's exact reference, not changed to a new label. All code integration and prior content corrections are ready and will be saved. The browser test reached FormSubmit but stopped at Cloudflare human verification, so no activation-email or inbox-delivery claim is established. Do not re-send the test or publish while this is unresolved. The owner may need to complete the existing browser verification, then activate the recipient through their own inbox. This supersedes Gmail SMTP implementation and credential testing outcomes.

## FormSubmit Unable to submit form correction

- [ ] Add FormSubmit's documented hidden _url field with a full HTTP(S) Contact Us page URL, working in Preview and published/custom-domain contexts. Exclude query strings and fragments from provider origin metadata. Retain native POST, fixed organization recipient, reference layout, CAPTCHA, names/email, message limits and previous changes. Validate the corrected form without resending a message or claiming inbox activation/delivery. Leave publication disabled and delivery/activation outcomes pending until the owner confirms.

The `_url` correction is implemented: initial HTML includes the full confirmed published contact-page URL, and hydration/submit use the actual current origin with /contact only. Queries, fragments and credentials are excluded; invalid/non-HTTP(S) URLs use the public fallback. Three new regressions pass, bringing the suite to 56 passing tests. TypeScript, static seven-page build, server bundle and diff checks pass. No new message was submitted and no claim of provider acceptance, activation or inbox delivery is established. Publication remains disabled. Retry once from the corrected Preview is the next user step.

## Remove pictured Get Support inquiry content

- [ ] Remove the pictured Keep your inquiry brief and Set realistic expectations blocks, A careful first step introduction, Make a careful initial inquiry titles, privacy link and entire alias/reply-email/message email-draft form, including its guidance, consent checkbox and Prepare email draft button. Preserve the Get Support hero, FAQs and navigation. Retain the working Contact Us FormSubmit form and prior corrections, and keep a route to Contact Us for support inquiries. Correct now-stale Privacy descriptions of the removed form. Verify and save the correction; do not claim the live website changed unless its publication succeeds.

The pictured Get Support section is removed in full: both guidance blocks, the intro/privacy link, and the entire draft form. The hero and all six FAQs remain, with a Contact Us link prefilled for Support request. Privacy no longer describes a removed draft form; FormSubmit disclosures and the working Contact Us form are unchanged. TypeScript, all 58 tests, seven-page static build, server bundle and diff checks pass. This supersedes prior keep-support-form requirements. Save this version without submitting a new publication; latest live version remains d481580 until a new release is approved.

## Contact Subject label

- [ ] Replace Objectif with Subject on Contact Us, including the field's accessible label. Keep field name, value handling, form appearance, email destination, submission behavior and prior corrections unchanged. Save and verify without automatically publishing.

Subject replaces Objectif in visible and accessible field labels. All 58 tests, TypeScript and the seven-page static build pass; Preview confirms the new label and unchanged FormSubmit recipient. Field behavior, design and prior removals are unchanged. This correction is saved but not republished.

## Leader's conference participation

- [ ] Add the supplied conference photograph to Home and About Us with a professional responsive leadership feature and caption explaining that the leader is attending a conference to work toward meaningful community impact. Preserve the complete image composition, omit embedded metadata and supplier labels, retain the original upload, and do not invent event names, dates, endorsements or measured results. Keep the official branding, contact form, Subject label, prior removals and page functions unchanged. Save and verify before any publication.

The new conference photo appears in a reusable Leadership in Action feature on Home and About Us. Its caption uses the supplied context: “Our leader attending a conference, working toward meaningful impact in our community.” No name/date/event/endorsement or measured-results claims were added. Complete 957×1280 composition is preserved with contain/auto sizing; original upload is untouched, website metadata stripped, and supplier labels omitted. All 61 tests, TypeScript and seven-page static build pass. Both Preview page placements and uploaded image HTTP 200/dimensions verified. Prior Subject and Get Support changes remain intact. This addition is saved in Preview, not yet published.

## Conference caption refinement

- [ ] Replace the awkward “Our leader attending a conference, working toward meaningful impact in our community” caption with natural, professional wording: “Representing Harbor of Hope at a conference, with a focus on dignity, protection, and opportunity for LGBTQ+ refugees.” Keep the photograph, layout and other content unchanged. Verify and save without publishing.

The new caption is applied on Home and About Us; the photograph and layout are unchanged. TypeScript, all 61 tests, and seven-page static build pass. Old caption absence and new caption presence verified in both generated pages. Saved only; publication remains pending.

## Conference paragraph refinement

- [ ] Replace the sentence “Our leader participates in conferences with a focus on making a meaningful impact in our community” with natural wording explaining conference participation as an effort to bring LGBTQ+ refugee needs into wider discussions of protection and inclusion. Retain the revised caption, photo, design and all prior corrections. Save and verify without republishing.

The paragraph now reads: “Through conference participation, Harbor of Hope seeks to bring the needs of LGBTQ+ refugees into wider conversations about protection and inclusion.” Old wording removed on both Home and About Us. The caption, photo and design are unchanged. TypeScript, all 61 tests, static build and public Preview checks pass. Saved only; not yet republished.

## October 21 — harborwebsite.docx corrections

- [x] **Audience, mission, vision and Home:** Replace Home's identify-needs paragraph with “We identify needs, connect LGBTQ+ refugees and asylum seekers with appropriate services, and seek resources and partnerships for practical assistance.” Use the supplied About hero beginning “We are a refugee-led organization in Uganda, working toward a future…” and include refugees and asylum seekers in primary organizational audience wording. Mission: “Our mission is to protect, support, and empower LGBTQ+ refugees and asylum seekers through community-based protection, access to essential services, human rights awareness, psychosocial support, livelihood opportunities, and strategic partnerships.” Vision: “An inclusive, safe, and dignified society where LGBTQ+ refugees and asylum seekers can live without fear.” Home/About share these values; preserve wider/current scope distinctions stated in the document.
- [x] **Full story, scope and objectives:** Use all supplied opening/chapter paragraphs, founding in 2024, Born from the Need for Safety. Built on Hope., Why We Began, What We Stand For, Our Journey., Our Hope., closing signature and tagline. Include the expanded food/security/healthcare/psychosocial/livelihood needs sentence. Keep stable chapter anchors. About's scope note reads “Our current programs and operations focus on LGBTQ+ refugees in Uganda. Our wider registered objectives also cover refugees, asylum seekers, and other LGBTQ+ community members.” Replace the rights-awareness objective with the supplied explicit LGBTQ+ refugees and asylum seekers wording. Do not add unprovided history or measured impact.
- [x] **Executive Director workshop:** On both Home and About, use “Through conferences and workshop participation, Harbor of Hope seeks to bring the needs of LGBTQ+ refugees into wider conversations about protection and inclusion.” Add that in March 2026 the Executive Director participated in the LGBTQ+ INCLUSION IN HUMANITARIAN RESPONSE workshop held in Kenya. Update the engagement paragraph to include LGBTQ+ refugees and asylum seekers in Uganda, and caption to “Representing Harbor of Hope at a workshop focused on dignity, protection, and opportunity for LGBTQ+ refugees and asylum seekers.” Keep the photograph, full composition and existing design; do not infer organizers or endorsements.
- [x] **Marked removals:** Remove “From our activities” and “Moments from Harbor of Hope activities, shared with permission and care for the people pictured.” from About while retaining both photos. Remove the governance paragraph beginning “Our governance arrangements are intended to support oversight…” while retaining the registered Memorandum/Articles sentence and accountability anchor. Remove the Before You Reach Out/Before you contact us FAQ section, its six questions and answers, retaining the Get Support page hero and a direct Contact Us action. Never show editing annotations such as REMOVE IT or MUST BE REMOVED publicly.
- [x] **Programs and preservation:** Use the document's Programs & Services introductory sentence and safe-shelter details beginning “We seek and coordinate support for LGBTQ+ refugees and asylum seekers.” Keep the three supplied shelter activities, all eight program areas and links, remaining approach/objective/partnership/priority content, logo/images, partner/donor logos, contact information, Subject label, working FormSubmit destination/source metadata, donation URL, prior removals and navigation unchanged. Save and verify the document changes without publishing or sending test messages.

### October 21 completion evidence

All five document-driven outcomes are implemented. The complete supplied story is retained with paragraph counts 5 / [5, 5, 3, 5], unchanged chapter anchors, new headings and audience language. Home/About share the exact new mission and vision; the owner-supplied March 2026 Executive Director workshop in Kenya and caption appear on both pages. Marked activity text, the single governance-arrangements paragraph and all six support FAQs are removed while their retained photos/hero/contact path and governance sentence/anchor remain. Programs text and safe-shelter activities align; all eight programs, donor content, logos/photos, contact details, Subject label, native FormSubmit destination/source field and donation link are preserved. TypeScript, all 67 regression tests, seven-page static build, server bundle, diff checks and seven Preview HTTP 200 route/manifest checks pass. An independent read-only comparison reports no concrete omissions or regressions. No email was submitted, secrets or platform settings changed, or publication requested. Review this saved version in Preview; the live website remains the previously published version until a separate approved release.

## Remove remaining Governance & Accountability section

- [x] Remove the complete About Us GOVERNANCE & ACCOUNTABILITY heading, Governance and accountability title and Harbor of Hope Refugee Support Initiative Ltd registered Memorandum/Articles/Ugandan law sentence. Remove the section's accountability anchor and all public links to /about#accountability from Home and footer so none lead to missing content. Align About metadata with the remaining story/mission/vision/values/approach. Keep unrelated accountability values/program and privacy guidance, latest document changes, photo/workshop details, contact form and donations unchanged. Verify, save and leave publication separate.

Full governance section removed from About Us, including both headings and the registered Memorandum/Articles statement. Removed Home and shared-footer links to the deleted anchor; About metadata now describes the remaining approach rather than governance. Unrelated accountability values, programs, privacy safeguards and all latest document corrections remain. TypeScript, all 67 tests, seven-page static build, server bundle and diff checks pass. Save only; no publication or test-email submission.

## Bottom placement of Our partners & donors on every page

- [x] Show the existing Our partners & donors section exactly once at the bottom of every public page (Home, About Us, Programs & Services, Partner & Support, Get Support, Contact Us, Privacy), after all page-specific content and immediately above the footer. Remove old Home/Partner placements. Keep all four supplied partner logos/names, full image proportions and original colors, accessible descriptions and responsive styling. Preserve all other content and recent corrections, contact/donation behavior and navigation. Save and verify without automatically publishing.

PartnerRecognition is now rendered exactly once as the final section inside the shared main element on all seven public pages, immediately before the footer. Removed old Home and Partner instances. All four original partner logos/names and accessible/responsive presentation are unchanged. TypeScript, all 67 tests, static seven-page build, server bundle and diff checks pass. Other content and recent document corrections are retained. Save only; no publication requested.

## Contact-page explanation removal and mission sentence

- [x] Remove the Contact Us “Submit continues to FormSubmit…” paragraph and its email-app/required-field/alias explanation; the “By submitting, you choose to share…” paragraph including provider processing, 30-day archive, 1200-character notice and privacy links; the safeguarding concern/developing mechanisms paragraph; the emergency/resources/sensitive-documents SafetyNote; and the postal walk-in/private-locations paragraph. Keep the actual email/telephone/postal address, all form fields, Subject, validation, native FormSubmit action/POST/_url and spam checks, program context, and underlying delivery behavior unchanged. Remove accessibility descriptions referencing the deleted form note, but keep field labels and the separate Privacy page/footer links. Preserve recent partner placement and all previous corrections.
- [x] Replace the shared mission with exactly “to protect, support, and empower LGBTQ+ refugees and asylum seekers through community-based protection, access to essential services, human rights awareness, psychosocial support, livelihood opportunities, and strategic partnerships.” on Home and About Us. Validate and save without publishing or sending a test email.

### Contact-copy cleanup completion evidence — October 22

Removed all five quoted contact-copy blocks, including both form explanations, safeguarding follow-up note, emergency/capacity SafetyNote and walk-in/private-operational-locations paragraph. Removed three aria-describedby references to the deleted note. Actual email, telephone and postal address remain, as do all reference form fields, native FormSubmit POST/action, source-page metadata, honeypot/spam checks, field limits, validation and program context. Independent Privacy page/footer privacy navigation and partners/donors bottom placement are unchanged. Shared mission now matches the user's exact lowercase “to protect, support, and empower…” sentence on Home and About. TypeScript, all 70 tests, seven-page production build, server bundle and diff checks pass; Preview is healthy (HTTP 200). No message submitted, provider settings changed or publication requested. Save this revision for Preview review.

## Homepage-only header illustration replacement

- [x] Use the supplied addthistohomepageonly.jpeg to replace only the main homepage header picture. Preserve the image's complete composition, original logo/lettering/colors and dimensions, optimize a separate website copy without embedded metadata, and keep the original file unchanged. Keep all other pages' hero pictures and every other photograph unchanged. Keep Home headline/actions/navigation and all latest content/form/partner-placement corrections. Use descriptive illustration alt text, prevent cropping with Home-only styling, and avoid mislabeling it as an activity photograph. Verify, save and leave publication separate.

The supplied illustration is now Home's main header image only, using a distinct durable managed WebP with exact original 1080×603 RGB pixels and no metadata. Alt text identifies it as an illustration, not an activity photograph. Home-only contain/top positioning preserves the full composition; existing live headlines/actions and mobile full-image sizing remain. All six other public page heroes, original activity-photo files, workshop picture and every recent content/form/partner-section correction are unchanged. TypeScript, all 73 tests, seven-page production build, server bundle and diff checks pass. No publication or form message sent; save for Preview review.

## Enlarge homepage refugee-led audience tagline

- [x] Make the existing “REFUGEE-LED ORGANIZATION · SUPPORTING LGBTQ+ REFUGEES & ASYLUM SEEKERS” text noticeably larger on Home, using 18px bold desktop text and 14px mobile text with natural wrapping. Keep exact wording, readable spacing/line height, supplied illustration, headline and buttons, other page typography, partner placement and previous corrections unchanged. Verify and save without publishing.

Home audience tagline is now 18px/700-weight on desktop and 14px on screens up to 700px, with readable spacing, line height and natural wrapping. Exact text, illustration, live headline/actions and all other page eyebrow sizing remain unchanged. TypeScript, all 74 tests, seven-page production build, server bundle and diff checks pass. Save only; publication remains separate.
