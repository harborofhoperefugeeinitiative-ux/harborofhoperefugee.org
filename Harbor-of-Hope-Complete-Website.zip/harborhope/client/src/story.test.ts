import { describe, expect, it } from "vitest";
import { render } from "./entry-server";
import { ourStory } from "./story";
import { organization } from "./content";

function escapeHtml(text: string) {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#x27;");
}

describe("Supplied organization story", () => {
  it("renders the entire introduction and all four unnumbered chapters in initial About Us HTML", () => {
    const { html } = render("/about");
    expect(ourStory.introduction).toHaveLength(5);
    expect(ourStory.chapters.map(chapter => chapter.paragraphs.length)).toEqual(
      [5, 5, 3, 5]
    );
    expect(html).toContain(ourStory.subtitle);
    for (const paragraph of ourStory.introduction)
      expect(html).toContain(escapeHtml(paragraph));
    for (const chapter of ourStory.chapters) {
      expect(html).toContain(chapter.title);
      expect(html).toContain(`href="#${chapter.id}"`);
      expect(html).toContain(`id="${chapter.id}"`);
      for (const paragraph of chapter.paragraphs)
        expect(html).toContain(escapeHtml(paragraph));
    }
    expect(html).toContain(ourStory.signature);
    expect(html).toContain(ourStory.tagline);
    expect(html).toContain("Founded</dt><dd>2024");
  });
  it("keeps the explicit leadership correction and the supplied participation meaning", () => {
    const { html } = render("/about");
    expect(html).not.toMatch(/community[- ]led/i);
    expect(html).toContain("Our organization is refugee-led");
    expect(html).toContain("must have a voice in shaping the solutions");
    expect(html).toContain("our resources are limited");
    expect(html).toContain("Our wider registered objectives");
  });
  it("links from Home while preserving other About Us sections and donation destination", () => {
    expect(render("/").html).toContain('href="/about#our-story"');
    const { html, head } = render("/about");
    expect(html).toContain('id="our-story"');
    expect(head).toContain("Founded in 2024");
    for (const content of [
      "OUR MISSION",
      "OUR VISION",
      'id="our-approach"',
      organization.donationUrl,
    ])
      expect(html).toContain(content);
    expect(html).not.toMatch(/\.docx|Organization_Profile|PROGRAM 0[1-9]/);
  });
  it("describes real displacement experiences without Imagine or invented individual cases", () => {
    const { html } = render("/about");
    expect(html).not.toMatch(/\bimagine\b/i);
    expect(html).toContain(
      "Many LGBTQ+ refugees and asylum seekers leave their home countries in search of safety"
    );
    expect(html).toContain(
      "they continue to face discrimination, rejection, fear"
    );
    expect(html).toContain("this is their reality");
  });
});
