import { describe, expect, it } from "vitest";
import { render } from "./entry-server";
import { organization } from "./content";

describe("User-requested screenshot content removal", () => {
  it("removes the screenshot guidance from Get Support without removing contact actions", () => {
    const { html } = render("/get-support");
    for (const text of [
      "If you face immediate danger",
      "Choose a safe channel",
      "Consider who else can see your screen",
      "We seek to connect community members",
      "WhatsApp opens a third-party service",
      "Your safety comes first.",
    ])
      expect(html).not.toContain(text);
    expect(html).not.toContain('class="emergency-note"');
    expect(html).not.toContain("Contact via WhatsApp");
    expect(html).toContain(organization.email);
    expect(html).not.toContain("Keep your inquiry brief");
    expect(html).not.toContain("Set realistic expectations");
    expect(html).not.toContain("Prepare email draft");
    expect(html).not.toContain("Before you contact us");
    expect(html).toContain('href="/privacy"');
  });
  it("removes About Us commitments and the subsequently removed governance section while retaining safeguarding navigation", () => {
    const { html } = render("/about");
    for (const text of [
      "Appropriate financial records and protection of assets",
      "Responsible management of conflicts of interest",
      "Careful protection of confidential information",
      "Developing suitable safeguarding and complaints mechanisms",
      "Applicable law, organizational controls, and donor requirements",
      "Our systems, partnerships, and program capacity continue to",
    ])
      expect(html).not.toContain(text);
    expect(html).not.toContain('class="accountability-columns"');
    expect(html).not.toContain('class="governance-summary"');
    expect(html).not.toContain('id="accountability"');
    expect(html).not.toContain(
      "registered Memorandum and Articles of Association"
    );
    expect(html).not.toContain("Our governance arrangements");
    expect(html).not.toContain("/about#accountability");
    expect(html).toContain('href="/contact?topic=Safeguarding%20concern"');
  });
  it("keeps the privacy page and factual corrections while removing the support form", () => {
    const privacy = render("/privacy").html;
    expect(privacy).toContain("Safeguarding and accountability");
    expect(privacy).toContain("participant consent");
    const support = render("/get-support").html;
    expect(support).not.toContain('name="consent"');
    expect(support).not.toContain("does not send or save");
    const about = render("/about").html;
    expect(about).not.toMatch(/80044148475426|\bimagine\b/i);
    expect(about).toContain(
      "Many LGBTQ+ refugees and asylum seekers leave their home countries in search of safety"
    );
    expect(about).toContain(organization.donationUrl);
  });
});
