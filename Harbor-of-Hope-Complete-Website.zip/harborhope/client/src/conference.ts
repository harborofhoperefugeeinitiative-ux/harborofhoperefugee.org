import type { ActivityPhotoData } from "./photos";

// Supplied by the organization for this leadership feature; no event details inferred.
export const conferencePhoto = {
  sourceNumber: 10,
  src: "/manus-storage/harbor-leader-conference_72230392.webp",
  width: 957,
  height: 1280,
  alt: "Harbor of Hope's leader standing behind a lectern in a conference room",
  caption:
    "Representing Harbor of Hope at a workshop focused on dignity, protection, and opportunity for LGBTQ+ refugees and asylum seekers.",
} satisfies ActivityPhotoData;
