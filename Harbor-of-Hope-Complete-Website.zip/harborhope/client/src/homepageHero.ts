import type { ActivityPhotoData } from "./photos";

// Supplied by Harbor of Hope for the homepage hero only; not an activity photo.
export const homepageHeroImage = {
  src: "/manus-storage/harbor-homepage-welcome-illustration_32faa5d2.webp",
  width: 1080,
  height: 603,
  alt: "Illustration of people welcoming one another at a harbor with rainbow Pride flags, a lighthouse, and the Harbor of Hope logo",
} satisfies Pick<ActivityPhotoData, "src" | "width" | "height" | "alt">;
