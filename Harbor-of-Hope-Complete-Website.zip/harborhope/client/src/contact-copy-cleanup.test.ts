import { describe, expect, it } from "vitest";
import { render } from "./entry-server";
import { organization } from "./content";

const removedCopy = [
  "Submit continues to FormSubmit",
  "You do not need to open an email app",
  "Required fields are marked",
  "You may use an alias",
  "By submitting, you choose to share",
  "retains a submission archive for 30 days",
  "Read our privacy and safety guidance",
  "FormSubmit privacy policy",
  "To raise a safeguarding concern, enter that subject",
  "Share only the minimum needed to request a safe follow-up",
  "Our safeguarding and complaints mechanisms are continuing to develop",
  "We are not an emergency service",
  "Responses and assistance depend on available resources and capacity",
  "Please do not send sensitive documents or private case details in your first message",
  "This is not a walk-in support or shelter address",
  "We do not publish private operational locations",
];

function textOf(html: string) {
  return html
    .replace(/<[^>]*>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

describe("Requested contact-page text cleanup and mission refinement", () => {
  it("removes every listed explanation without leaving dangling accessibility descriptions", () => {
    const html = render("/contact").html;
    const text = textOf(html);
    for (const phrase of removedCopy) expect(text).not.toContain(phrase);
    expect(html).not.toContain('id="contact-form-note"');
    expect(html).not.toContain('aria-describedby="contact-form-note"');
    expect(html).not.toContain('class="safety-note"');
  });
  it("retains contact information, form delivery, validation, privacy navigation and bottom partner placement", () => {
    const html = render("/contact").html;
    expect(html).toContain(
      `action="https://formsubmit.co/${organization.email}"`
    );
    expect(html).toContain('method="POST"');
    for (const name of [
      "firstName",
      "lastName",
      "email",
      "topic",
      "message",
      "_url",
      "_honey",
      "_subject",
      "_template",
    ])
      expect(html).toContain(`name="${name}"`);
    expect(html).toContain('maxLength="1200"');
    expect(html).toContain('aria-label="Subject"');
    expect(html).not.toContain('name="_captcha"');
    expect(html).toContain(organization.email);
    expect(html).toContain(organization.phone);
    expect(html).toContain(organization.address);
    expect(html).toContain('href="/privacy"');
    expect(html).toMatch(/<\/section>\s*<\/main>\s*<footer/);
    const privacy = render("/privacy").html;
    expect(privacy).toContain("FormSubmit processes submissions");
    expect(privacy).toContain("for 30 days");
    expect(privacy).toContain("Safeguarding and accountability");
  });
  it("uses the exact mission without its previous prefix on Home and About Us", () => {
    expect(organization.mission).toBe(
      "to protect, support, and empower LGBTQ+ refugees and asylum seekers through community-based protection, access to essential services, human rights awareness, psychosocial support, livelihood opportunities, and strategic partnerships."
    );
    for (const path of ["/", "/about"]) {
      const html = render(path).html;
      expect(textOf(html)).toContain(organization.mission);
      expect(html).not.toContain("Our mission is to protect");
    }
  });
});
