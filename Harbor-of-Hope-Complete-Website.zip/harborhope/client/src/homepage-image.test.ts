import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { render } from "./entry-server";
import { routes } from "./content";
import { homepageHeroImage } from "./homepageHero";
import { activityPhotos } from "./photos";
import { conferencePhoto } from "./conference";

function heroImage(html: string) {
  return html.match(/<img[^>]*class="photo-hero-image"[^>]*>/)![0];
}

describe("Supplied homepage-only harbor illustration", () => {
  it("replaces only Home's main hero while retaining its text, controls and other images", () => {
    const html = render("/").html;
    const hero = heroImage(html);
    expect(hero).toContain(homepageHeroImage.src);
    expect(hero).toContain('width="1080" height="603"');
    expect(hero).toContain("Illustration of people welcoming");
    expect(html).not.toContain(activityPhotos.pride.src);
    expect(html).toContain(conferencePhoto.src);
    expect(html).toContain("Safety is a beginning.");
    expect(html).toContain("Hope is a practice.");
    expect(html).toContain('href="/get-support"');
    expect(html).toContain('href="/about#our-approach"');
  });
  it("does not place the new image on any other page or alter their hero photos", () => {
    const others = {
      "/about": activityPhotos.welcome,
      "/programs": activityPhotos.outreach,
      "/partner": activityPhotos.exchange,
      "/contact": activityPhotos.connections,
      "/get-support": activityPhotos.solidarity,
      "/privacy": activityPhotos.community,
    };
    for (const route of routes.filter(route => route.path !== "/")) {
      const html = render(route.path).html;
      expect(html).not.toContain(homepageHeroImage.src);
      expect(heroImage(html)).toContain(
        others[route.path as keyof typeof others].src
      );
    }
  });
  it("keeps the illustration complete with a Home-only contain rule and retains mobile full-image sizing", () => {
    const css = readFileSync(
      new URL("./styles/hero.css", import.meta.url),
      "utf8"
    );
    expect(css).toMatch(
      /\.reference-home-hero \.photo-hero-image\s*\{[^}]*object-fit: contain;[^}]*object-position: center top;/
    );
    expect(css).toMatch(
      /@media \(max-width: 700px\)[\s\S]*\.photo-hero-image\s*\{[^}]*height: auto;[^}]*object-fit: contain;/
    );
  });
  it("makes the homepage audience tagline larger while keeping responsive wrapping and exact wording", () => {
    const css = readFileSync(
      new URL("./styles/hero.css", import.meta.url),
      "utf8"
    );
    expect(css).toMatch(
      /\.reference-home-hero \.photo-hero-eyebrow\s*\{[^}]*font-size: 18px;[^}]*font-weight: 700;[^}]*max-width: 1000px;/
    );
    expect(css).toMatch(
      /@media \(max-width: 700px\)[\s\S]*\.reference-home-hero \.photo-hero-eyebrow\s*\{[^}]*font-size: 14px;/
    );
    expect(render("/").html).toContain(
      "REFUGEE-LED ORGANIZATION · SUPPORTING LGBTQ+ REFUGEES &amp; ASYLUM SEEKERS"
    );
  });
});
