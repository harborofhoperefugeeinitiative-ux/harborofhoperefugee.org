// Official Harbor of Hope artwork extracted from the supplied organization logo PDF.
// The symbol and lettering are preserved; only surrounding poster layout is omitted.
import { siteAssetUrl } from "./siteConfig";

export const branding = {
  mark: "/manus-storage/harbor-official-mark_6fb75bb5.png",
  fullLogo: "/manus-storage/harbor-official-logo_d594abf3.png",
  publicMark: siteAssetUrl("/manus-storage/harbor-official-mark_6fb75bb5.png"),
  icon: "/harbor-official-icon.png",
};
