import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { render } from "./entry-server";
import { conferencePhoto } from "./conference";

describe("Leader conference photograph", () => {
  it("shows the supplied photo and contextual caption on Home and About Us", () => {
    for (const path of ["/", "/about"]) {
      const html = render(path).html;
      expect(html).toContain(conferencePhoto.src);
      expect(html).toContain('width="957" height="1280"');
      expect(html).toContain("leader standing behind a lectern");
      expect(html).toContain(conferencePhoto.caption);
      expect(html).toContain('id="leadership-in-action"');
      expect(html).not.toContain("Photo supplied by Harbor of Hope");
      expect(html).toContain(
        "Through conferences and workshop participation, Harbor of Hope seeks to bring the needs of LGBTQ+ refugees into wider conversations about protection and inclusion."
      );
      expect(html).toContain(
        "In March 2026, our Executive Director participated in a workshop"
      );
      expect(html).toContain("LGBTQ+ INCLUSION IN HUMANITARIAN RESPONSE");
      expect(html).toContain("held in Kenya.");
      expect(html).not.toContain("Our leader participates in conferences");
    }
  });
  it("preserves the full image at desktop and mobile widths", () => {
    const css = readFileSync(
      new URL("./styles/brand.css", import.meta.url),
      "utf8"
    );
    expect(css).toMatch(
      /\.conference-feature \.conference-photo img\s*\{[^}]*height: auto;[^}]*object-fit: contain;/
    );
    expect(css).toMatch(
      /@media \(max-width: 760px\)[\s\S]*\.conference-feature\s*\{\s*grid-template-columns: minmax\(0, 1fr\);/
    );
  });
  it("retains the Subject correction, contact delivery and support-form removal", () => {
    const contact = render("/contact").html;
    expect(contact).toContain(">Subject</label>");
    expect(contact).toContain(
      'action="https://formsubmit.co/harborofhoperefugeeinitiative@gmail.com"'
    );
    expect(render("/get-support").html).not.toContain("Prepare email draft");
  });
});
