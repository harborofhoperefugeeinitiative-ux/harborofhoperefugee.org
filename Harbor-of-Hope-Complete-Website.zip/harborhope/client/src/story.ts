export const ourStory = {
  title: "Our Story",
  subtitle: "Born from the Need for Safety. Built on Hope.",
  founded: 2024,
  introduction: [
    "Harbor of Hope Refugee Support Initiative was created and founded in 2024 from a simple belief: no LGBTQ+ refugee and asylum seeker should have to suffer alone because of who they are or whom they love.",
    "Many LGBTQ+ refugees and asylum seekers leave their home countries in search of safety, separated from loved ones and the lives they knew. After arriving somewhere new in search of peace, they continue to face discrimination, rejection, fear, and uncertainty about tomorrow.",
    "For many LGBTQ+ refugees and asylum seekers in Uganda, this is their reality.",
    "Behind every refugee is a human being with a story. Someone who dreams of living in peace, finding a safe place to sleep, accessing healthcare, earning a living, and being accepted for who they are. Yet many face barriers to basic needs, protection, and the opportunity to rebuild their lives.",
    "We created Harbor of Hope because we believe that LGBTQ+ refugees' and asylum seekers’ lives matter, every person deserves dignity, and nobody should be left behind.",
  ],
  chapters: [
    {
      id: "why-we-began",
      title: "Why We Began",
      paragraphs: [
        "In 2024, Harbor of Hope Refugee Support Initiative was founded in response to the challenges faced by LGBTQ+ refugees and asylum seekers who were struggling to find safety, support, and a sense of belonging.",
        "We recognized the need for a refugee-led organization that listens to LGBTQ+ refugees and asylum seekers, understands their experiences, and works alongside them to find practical solutions.",
        "We wanted to help create a space where people could feel heard rather than ignored, supported rather than abandoned, and valued rather than judged.",
        "Our purpose was never to create another organization. It was to stand with LGBTQ+ refugees and asylum seekers whose voices are too often unheard and to help those facing difficult circumstances find support, protection, and renewed hope.",
        "We did not begin because we had all the answers or all the resources. We began because we believed that LGBTQ+ refugees and asylum seekers in need deserved someone willing to stand beside them.",
      ],
    },
    {
      id: "what-we-stand-for",
      title: "What We Stand For",
      paragraphs: [
        "Today, our commitment remains rooted in care, protection, human rights, and empowerment.",
        "We work to support LGBTQ+ refugees and asylum seekers in Uganda through protection support, safe shelter initiatives, healthcare referrals, psychosocial support, human rights awareness, and livelihood empowerment.",
        "We believe that support should go beyond words. It should help LGBTQ+ refugees and asylum seekers meet urgent needs, access essential services, understand their rights, and find opportunities to build more secure futures.",
        "Sometimes, hope means helping someone find a safer place to stay. Sometimes, it means connecting someone to healthcare or listening when they feel they have nobody to turn to. Every act of support matters because behind every need is a human life.",
        "Our organization is refugee-led, and we believe the people closest to the challenges must have a voice in shaping the solutions.",
      ],
    },
    {
      id: "our-journey",
      title: "Our Journey.",
      paragraphs: [
        "The journey has not been easy. Our community faces significant needs like safe shelter, food security, health care, psychosocial support, and livelihood support, yet our resources are limited. We know that we cannot reach everyone who needs help, and that reality reminds us how important solidarity and partnerships are.",
        "We continue to seek partnerships with donors, human rights organizations, service providers, and allies who share our belief that LGBTQ+ refugees and asylum seekers deserve safety, dignity, and opportunities to rebuild their lives.",
        "We cannot do this work alone. Together, we can strengthen community support, reach more people in need, and create opportunities for lasting change.",
      ],
    },
    {
      id: "hope-for-tomorrow",
      title: "Our Hope.",
      paragraphs: [
        "Our dream is a future where LGBTQ+ refugees and asylum seekers can live without fear, access essential services without discrimination, find safety when they need it, and pursue their dreams with dignity.",
        "We want everyone who comes into contact with Harbor of Hope to know one thing: your life matters, your story matters, and you deserve hope.",
        "Harbor of Hope is more than a name. It is a promise to keep caring, keep standing together, and keep working toward a future where no one is forgotten.",
        "Our story began in 2024, but the hope that inspired us continues today.",
        "Because every person deserves safety. Every person deserves dignity. And every person deserves a chance to begin again.",
      ],
    },
  ],
  signature: "Harbor of Hope Refugee Support Initiative",
  tagline: "Care. Protect. Empower. Together, We Bring Hope.",
};
