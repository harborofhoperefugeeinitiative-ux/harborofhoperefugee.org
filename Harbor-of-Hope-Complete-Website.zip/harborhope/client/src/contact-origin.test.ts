import { describe, expect, it } from "vitest";
import { render } from "./entry-server";
import {
  contactPageUrl,
  publishedContactUrl,
} from "./components/harbor/ContactForm";

describe("FormSubmit source-page metadata", () => {
  it("includes a full source URL in initial HTML without relying on a referrer", () => {
    const html = render("/contact").html;
    expect(html).toContain(`name="_url" value="${publishedContactUrl}"`);
    expect(html).toContain('method="POST"');
    expect(html).toContain(
      'action="https://formsubmit.co/harborofhoperefugeeinitiative@gmail.com"'
    );
    expect(html).not.toContain('name="_captcha"');
  });
  it("uses the actual Preview or custom-domain origin without queries, fragments, or credentials", () => {
    for (const origin of [
      "https://8328-idrxfvpsamtqr5qppz5eu-93ea34fc.us1.manus.computer",
      "https://harborofhoperefugee.org",
      "http://localhost:3000",
    ]) {
      expect(
        contactPageUrl(
          `${origin}/contact?topic=Safeguarding&program=health-access#message`
        )
      ).toBe(`${origin}/contact`);
    }
    expect(
      contactPageUrl("https://user:pass@example.org/contact?private=yes")
    ).toBe("https://example.org/contact");
  });
  it("uses the public fallback for invalid or non-web addresses", () => {
    for (const href of [
      undefined,
      "invalid",
      "file:///tmp/contact.html",
      "javascript:alert(1)",
    ]) {
      expect(contactPageUrl(href)).toBe(publishedContactUrl);
    }
  });
});
