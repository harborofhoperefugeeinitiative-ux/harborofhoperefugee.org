import { useEffect } from "react";
import Home from "./pages/harbor/Home";
import About from "./pages/harbor/About";
import Programs from "./pages/harbor/Programs";
import {
  Contact,
  GetSupport,
  Partner,
  Privacy,
} from "./pages/harbor/Engagement";
import { Header, Footer, ButtonLink } from "./components/harbor/Layout";
import PartnerRecognition from "./components/harbor/PartnerRecognition";
import { routeFor } from "./content";

export default function App({ initialPath }: { initialPath?: string }) {
  const rawPath =
    initialPath ||
    (typeof window !== "undefined" ? window.location.pathname : "/");
  const path = rawPath.length > 1 ? rawPath.replace(/\/$/, "") : rawPath;
  const route = routeFor(path);
  useEffect(() => {
    if (route) document.title = route.title;
  }, [route]);
  const pages: Record<string, React.ReactNode> = {
    "/": <Home />,
    "/about": <About />,
    "/programs": <Programs />,
    "/partner": <Partner />,
    "/contact": <Contact />,
    "/get-support": <GetSupport />,
    "/privacy": <Privacy />,
  };
  return (
    <>
      <a className="skip-link" href="#main-content">
        Skip to main content
      </a>
      <Header path={path} />
      <main id="main-content">
        {pages[path] || (
          <section className="section shell not-found">
            <span className="eyebrow">404 / PAGE NOT FOUND</span>
            <h1>
              Let's find
              <br />
              <em>a way forward.</em>
            </h1>
            <p>
              This page doesn't exist. You can return home or find information
              about support.
            </p>
            <div className="actions">
              <ButtonLink href="/">Back to home</ButtonLink>
              <ButtonLink href="/get-support" kind="outline">
                Help & support
              </ButtonLink>
            </div>
          </section>
        )}
        {route && <PartnerRecognition />}
      </main>
      <Footer />
    </>
  );
}
