import { describe, expect, it } from "vitest";
import { render } from "./entry-server";
import { organization, routes } from "./content";

describe("Postal-only label removal", () => {
  it("omits the requested phrase on all pages while preserving the address", () => {
    for (const route of routes) {
      const { html, head } = render(route.path);
      expect(html + head).not.toMatch(/postal address only/i);
      expect(html).toContain(organization.address);
      expect(html).toContain(organization.email);
    }
    const contact = render("/contact").html;
    expect(contact).toContain("POSTAL ADDRESS</small>");
    expect(contact).toContain("reference-contact-form");
  });
});
