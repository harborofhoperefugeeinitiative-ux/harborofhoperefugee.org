import { describe, expect, it } from "vitest";
import { render } from "./entry-server";
import { organization, programs, routes } from "./content";
import { ourStory } from "./story";
import { activityPhotos } from "./photos";
import { conferencePhoto } from "./conference";

function plain(html: string) {
  return html
    .replace(/<[^>]*>/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&#x27;/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}

describe("October 21 harborwebsite.docx content", () => {
  it("uses the new shared mission and vision on Home and About", () => {
    expect(organization.mission).toBe(
      "to protect, support, and empower LGBTQ+ refugees and asylum seekers through community-based protection, access to essential services, human rights awareness, psychosocial support, livelihood opportunities, and strategic partnerships."
    );
    expect(organization.vision).toBe(
      "An inclusive, safe, and dignified society where LGBTQ+ refugees and asylum seekers can live without fear."
    );
    for (const path of ["/", "/about"]) {
      const text = plain(render(path).html);
      expect(text).toContain(organization.mission);
      expect(text).toContain(organization.vision);
    }
    expect(plain(render("/").html)).toContain(
      "We identify needs, connect LGBTQ+ refugees and asylum seekers with appropriate services, and seek resources and partnerships for practical assistance."
    );
  });
  it("includes the supplied asylum-seeker story and keeps its stable chapter anchors", () => {
    expect(ourStory.introduction[0]).toContain("created and founded in 2024");
    expect(ourStory.introduction[1]).toContain(
      "refugees and asylum seekers leave their home countries"
    );
    expect(ourStory.chapters.map(chapter => chapter.title)).toEqual([
      "Why We Began",
      "What We Stand For",
      "Our Journey.",
      "Our Hope.",
    ]);
    expect(ourStory.chapters[2].paragraphs[0]).toContain(
      "safe shelter, food security, health care, psychosocial support, and livelihood support"
    );
    const html = render("/about").html;
    for (const chapter of ourStory.chapters)
      expect(html).toContain(`id="${chapter.id}"`);
    const text = plain(html);
    expect(text).toContain(
      "working toward a future where every LGBTQ+ refugee and asylum seeker can live with safety, dignity, and possibility."
    );
    expect(text).toContain(
      "Our current programs and operations focus on LGBTQ+ refugees in Uganda. Our wider registered objectives also cover refugees, asylum seekers, and other LGBTQ+ community members."
    );
    expect(text).toContain(
      "Promote human rights awareness and help LGBTQ+ refugees and asylum seekers understand and seek to exercise their rights."
    );
  });
  it("adds the March 2026 Executive Director workshop on both pages with the supplied photo", () => {
    for (const path of ["/", "/about"]) {
      const html = render(path).html;
      const text = plain(html);
      expect(text).toContain(
        "Through conferences and workshop participation, Harbor of Hope seeks to bring the needs of LGBTQ+ refugees into wider conversations about protection and inclusion."
      );
      expect(text).toContain(
        "In March 2026, our Executive Director participated in a workshop, LGBTQ+ INCLUSION IN HUMANITARIAN RESPONSE , held in Kenya."
      );
      expect(text).toContain(
        "protecting, and empowering LGBTQ+ refugees and asylum seekers in Uganda."
      );
      expect(text).toContain(conferencePhoto.caption);
      expect(html).toContain(conferencePhoto.src);
    }
    expect(conferencePhoto.caption).toBe(
      "Representing Harbor of Hope at a workshop focused on dignity, protection, and opportunity for LGBTQ+ refugees and asylum seekers."
    );
  });
  it("removes marked About text and the subsequently removed governance section but preserves activity photos", () => {
    const html = render("/about").html;
    expect(html).not.toMatch(
      /From our activities|Moments from Harbor of Hope activities|Our governance arrangements are intended/
    );
    expect(html).toContain(activityPhotos.community.src);
    expect(html).toContain(activityPhotos.pride.src);
    expect(html).not.toContain('id="accountability"');
    expect(plain(html)).not.toContain(
      "Harbor of Hope Refugee Support Initiative Ltd operates under its registered Memorandum and Articles of Association and applicable Ugandan law."
    );
    for (const route of routes) {
      expect(render(route.path).html).not.toMatch(
        /\/about#accountability|Governance (?:and|&amp;) accountability|GOVERNANCE &amp; ACCOUNTABILITY/
      );
    }
  });
  it("removes all six support FAQs without removing support navigation and Contact Us", () => {
    const html = render("/get-support").html;
    expect(html).not.toMatch(
      /BEFORE YOU REACH OUT|Before you contact us|<details|faq-list|faq-layout|program focus\?|accommodation or financial assistance\?|identity or case history\?|shelter address\?|email completely confidential\?|Quick exit do\?/i
    );
    expect(html).toContain(activityPhotos.solidarity.src);
    expect(html).toContain('href="/contact?topic=Support%20request"');
    const contact = render("/contact").html;
    expect(contact).toContain(
      'action="https://formsubmit.co/harborofhoperefugeeinitiative@gmail.com"'
    );
    expect(contact).toContain('name="_url"');
    expect(contact).toContain('aria-label="Subject"');
  });
  it("uses supplied program copy while retaining all eight programs, donor links and clean public text", () => {
    const html = render("/programs").html;
    expect(plain(html)).toContain(
      "The areas of work that support our mission are to protect, support, and empower LGBTQ+ refugees in Uganda. Every program begins with dignity."
    );
    expect(programs[0].details).toBe(
      "We seek and coordinate support for LGBTQ+ refugees and asylum seekers. Depending on available resources, this may include emergency accommodation support, safety planning, essential items, and referrals. Private shelter locations are never shared publicly."
    );
    expect(programs[0].activities).toEqual([
      "Emergency accommodation coordination",
      "Safety planning and protection referrals",
      "Essential items, where resources allow",
    ]);
    expect(programs).toHaveLength(8);
    for (const route of routes) {
      const result = render(route.path);
      expect(result.status).toBe(200);
      expect(result.html).toContain(organization.donationUrl);
      expect(result.html).not.toMatch(
        /REMOVE IT|MUST BE REMOVED|\(remove it\)|80044148475426|Objectif/
      );
    }
  });
});
