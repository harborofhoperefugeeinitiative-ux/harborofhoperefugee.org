import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { render } from "./entry-server";
import { routes } from "./content";
import { activityPhotos } from "./photos";
import { homepageHeroImage } from "./homepageHero";

const heroCss = readFileSync(
  new URL("./styles/hero.css", import.meta.url),
  "utf8"
);
const main = readFileSync(new URL("./main.tsx", import.meta.url), "utf8");
const routeManifest = JSON.parse(
  readFileSync(new URL("../public/manus-routes.json", import.meta.url), "utf8")
);

describe("Reference homepage and photo-led pages", () => {
  it("keeps Home and About Us as distinct pages with explicit navigation", () => {
    for (const route of routes) {
      const { html } = render(route.path);
      expect(html).toContain('href="/"');
      expect(html).toContain('href="/about"');
      expect(html).toContain(">Home</a>");
      expect(html).toContain(">About Us</a>");
    }
    expect(render("/about").html).toContain("<h1>About Us</h1>");
    expect(
      routeManifest.routes.find(
        (route: { path: string; title: string }) => route.path === "/about"
      ).title
    ).toBe("About Us");
    expect(
      routeManifest.routes.map((route: { path: string }) => route.path)
    ).toEqual(routes.map(route => route.path));
  });
  it("keeps the reference layout and live controls with the newly supplied homepage illustration", () => {
    const { html } = render("/");
    expect(html).toContain("Safety is a beginning.");
    expect(html).toContain("Hope is a practice.");
    expect(html).toContain(homepageHeroImage.src);
    expect(html).toContain('class="hero-line hero-gold"');
    expect(html).toContain('class="button button-coral" href="/get-support"');
    expect(html).toContain('href="/about#our-approach"');
    expect(html).toContain('href="/#why-it-matters"');
    expect(html).toContain('href="http://spot.fund/d8qhqnrsc"');
    expect(html).toContain("Quick exit");
    expect(html).toContain("REFUGEE-LED ORGANIZATION");
    expect(html).not.toContain("homepage.jpeg");
    expect(main.indexOf('"./styles/hero.css"')).toBeGreaterThan(
      main.indexOf('"./styles/brand.css"')
    );
    expect(heroCss).toContain("font-family: var(--font-display)");
    expect(heroCss).toMatch(/linear-gradient\(\s*90deg/);
  });
  it("includes a complete hero image with descriptive alt text and meaningful content on every route", () => {
    const photos: Record<string, typeof homepageHeroImage> = {
      "/": homepageHeroImage,
      "/about": activityPhotos.welcome,
      "/programs": activityPhotos.outreach,
      "/partner": activityPhotos.exchange,
      "/contact": activityPhotos.connections,
      "/get-support": activityPhotos.solidarity,
      "/privacy": activityPhotos.community,
    };
    for (const route of routes) {
      const { html } = render(route.path);
      expect(html).toContain('class="photo-hero-image"');
      expect(html).toContain(`src="${photos[route.path].src}"`);
      expect(html).toContain(`alt="${photos[route.path].alt}"`);
      expect(html).not.toContain("Harbor of Hope activity photograph");
      expect(html).not.toContain('class="photo-hero-credit"');
      expect(html.match(/<h1[ >]/g)).toHaveLength(1);
    }
    expect(heroCss).toMatch(
      /@media \(max-width: 700px\)[\s\S]*\.photo-hero-image\s*\{[^}]*height: auto;[^}]*object-fit: contain;/
    );
  });
  it("removes decorative numbering without losing meaningful organization details", () => {
    for (const route of routes) {
      const { html } = render(route.path);
      expect(html).not.toMatch(
        /\b0[1-9]\s*\/|PROGRAM 0[1-9]|class="approach-number"|class="section-number"|<span>0[1-9]<\/span>/
      );
      expect(html).not.toContain("80044148475426");
      expect(html).toContain("+256 790 448 018");
    }
  });
});
