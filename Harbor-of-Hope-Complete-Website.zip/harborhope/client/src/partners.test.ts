import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { render } from "./entry-server";
import { partnersAndDonors } from "./partners";
import { activityPhotos } from "./photos";
import { routes } from "./content";
import { homepageHeroImage } from "./homepageHero";

const styles = readFileSync(
  new URL("./styles/brand.css", import.meta.url),
  "utf8"
);

describe("User-confirmed partners and donors", () => {
  it("acknowledges the four supplied organizations once at the bottom of every public page", () => {
    expect(partnersAndDonors.map(partner => partner.id)).toEqual([
      "hrapf",
      "ucaa-ug",
      "rainbow-railroad",
      "international-pride-centre",
    ]);
    for (const route of routes) {
      const { html } = render(route.path);
      expect(html).toContain('aria-labelledby="partners-donors-title"');
      expect(html).toContain("Our partners &amp; donors");
      expect(html.split('id="partners-donors-title"').length - 1).toBe(1);
      const index = html.indexOf('<section class="partner-recognition"');
      expect(index).toBe(html.lastIndexOf("<section"));
      expect(index).toBeLessThan(html.indexOf("</main>"));
      expect(html).toMatch(/<\/section>\s*<\/main>\s*<footer/);
      for (const partner of partnersAndDonors) {
        expect(html).toContain(partner.name);
        expect(html).toContain(`src="${partner.logo}"`);
        expect(html).toContain(
          `width="${partner.width}" height="${partner.height}"`
        );
        expect(html).toContain(
          `${partner.shortName ? `(${partner.shortName}) ` : ""}logo`
        );
      }
    }
  });
  it("preserves source logo colors and complete proportions in a responsive layout", () => {
    expect(styles).toMatch(
      /\.recognition-logo img\s*\{[^}]*height: auto;[^}]*object-fit: contain;/
    );
    expect(styles).toContain(".recognition-list");
    expect(styles).toMatch(
      /@media \(max-width: 650px\)[\s\S]*\.recognition-list\s*\{\s*grid-template-columns: 1fr;/
    );
    expect(styles).not.toMatch(/filter\s*:/);
    expect(new Set(partnersAndDonors.map(partner => partner.logo)).size).toBe(
      4
    );
  });
  it("does not replace the existing activity images with the identically numbered new attachments", () => {
    expect(render("/").html).toContain(homepageHeroImage.src);
    expect(render("/about").html).toContain(activityPhotos.community.src);
    expect(render("/about").html).toContain(activityPhotos.welcome.src);
    expect(render("/partner").html).toContain(activityPhotos.connections.src);
    for (const partner of partnersAndDonors) {
      expect(
        Object.values(activityPhotos).some(photo => photo.src === partner.logo)
      ).toBe(false);
    }
  });
  it("distinguishes named acknowledgments from incidental signs in photographs", () => {
    const { html } = render("/privacy");
    expect(html).toContain("formal partnership or endorsement");
    expect(html).toContain(
      "identified by Harbor of Hope as its partners and donors"
    );
  });
});
