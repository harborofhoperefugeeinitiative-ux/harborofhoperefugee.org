import { describe, expect, it } from "vitest";
import { render, fillDocument } from "./entry-server";
import { organization, programs, routes } from "./content";
import { buildInquiry } from "./components/harbor/InquiryForm";
import { homepageHeroImage } from "./homepageHero";

describe("Harbor of Hope public content", () => {
  it("uses the supplied contact details without public registration data", () => {
    expect(organization.email).toBe("harborofhoperefugeeinitiative@gmail.com");
    expect(organization.phone).toBe("+256 790 448 018");
    expect(organization).not.toHaveProperty("registration");
    expect(organization.address).toBe("P. O. Box 209824, Kampala, Uganda");
  });
  it("renders complete initial HTML and distinct metadata for every public route", () => {
    expect(routes).toHaveLength(7);
    for (const route of routes) {
      const result = render(route.path);
      expect(result.status).toBe(200);
      expect(result.html).toContain("<h1");
      expect(result.html).toContain("Skip to main content");
      expect(result.html).toContain(organization.email);
      expect(result.head).toContain(
        `<title>${route.title.replace(/&/g, "&amp;")}</title>`
      );
      expect(result.head).toContain('name="description"');
      expect(result.head).not.toContain('rel="canonical"');
      expect(result.html + result.head).not.toMatch(
        /80044148475426|Registration No\.|Registration number/i
      );
    }
  });
  it("includes all eight program areas and matching jump destinations", () => {
    const { html } = render("/programs");
    expect(programs).toHaveLength(8);
    for (const program of programs) {
      expect(html).toContain(`id="${program.id}"`);
      expect(html).toContain(`href="#${program.id}"`);
    }
    expect(html).toContain("available resources");
  });
  it("preserves form delivery and field limits without the removed contact explanations", () => {
    const { html } = render("/contact");
    expect(html).toContain(">Submit</button>");
    expect(html).not.toContain("By submitting, you choose to share");
    expect(html).toContain(
      `action="https://formsubmit.co/${organization.email}"`
    );
    expect(html).toContain('maxLength="1200"');
    expect(html).not.toContain("Responses and assistance depend on");
    expect(html).toContain('name="email"');
    expect(html).not.toContain('type="file"');
    const support = render("/get-support").html;
    expect(support).not.toContain("<form");
    expect(support).not.toContain("Prepare email draft");
    expect(support).toContain('href="/contact?topic=Support%20request"');
  });
  it("returns a real not-found rendering with noindex", () => {
    const result = render("/missing");
    expect(result.status).toBe(404);
    expect(result.head).toContain('name="robots" content="noindex"');
    expect(result.html).toContain("This page doesn&#x27;t exist");
  });
  it("fills document placeholders without duplicating or dropping content", () => {
    const template =
      '<html><head><!--app-head--></head><body><div id="root"><!--app-html--></div></body></html>';
    const result = fillDocument(template, "/about");
    expect(result.html).not.toContain("<!--app-");
    expect(result.html).toContain("About Us");
    expect(result.html).toContain(organization.address);
  });
});

describe("Inquiry draft preparation", () => {
  it("addresses the exact organization mailbox and safely encodes special characters", () => {
    const draft = buildInquiry({
      topic: "Partnership",
      name: "  Alex & Sam  ",
      reply: "reply@example.org",
      message: "We can offer training & skills.\nPlease reply when possible.",
    });
    expect(
      draft.mailto.startsWith(`mailto:${organization.email}?subject=`)
    ).toBe(true);
    const params = new URLSearchParams(draft.mailto.split("?")[1]);
    expect(params.get("subject")).toBe("Harbor of Hope — Partnership");
    expect(params.get("body")).toContain("Name / alias: Alex & Sam");
    expect(params.get("body")).toContain("training & skills.");
    expect(params.get("body")).toContain("Safe reply email: reply@example.org");
  });
  it("does not require a name or introduce identity details", () => {
    const draft = buildInquiry({
      topic: "Support request",
      name: "",
      reply: "safe@example.org",
      message: "I would like information about health referrals.",
    });
    expect(draft.body).not.toContain("Name / alias");
    expect(draft.body).toContain("Support request");
    expect(draft.body).not.toContain("location");
  });
});

describe("Program-specific partnership inquiries", () => {
  it("preserves the selected program in the contact link and email draft", () => {
    const { html } = render("/programs");
    for (const program of programs) {
      expect(html).toContain(`program=${program.id}`);
    }
    const draft = buildInquiry({
      topic: "Partnership",
      name: "",
      reply: "partner@example.org",
      message: "We would like to discuss a referral partnership.",
      program: programs[1].title,
    });
    expect(draft.body).toContain(`Program area: ${programs[1].title}`);
  });
});

describe("Supplied contextual image", () => {
  it("places the Uganda and Pride flags in Why It Matters with descriptive alt text", () => {
    const { html } = render("/");
    expect(html).toContain("/manus-storage/uganda-pride-flags_cd0ea0f1.webp");
    expect(html).toContain("why-image context-image");
    expect(html).toContain(
      "Ugandan national flag alongside a Progress Pride flag"
    );
    expect(html).toContain('width="1280" height="726"');
    expect(html).not.toContain("Image supplied by Harbor of Hope");
  });
  it("describes supplied context imagery without a stale generated-art disclosure", () => {
    const { html } = render("/privacy");
    expect(html).toContain("Progress Pride flags image was supplied");
    expect(html).not.toContain("AI-generated");
    expect(render("/about").html).not.toContain("Conceptual artwork");
  });
});

describe("Cleared Harbor of Hope activity photos", () => {
  it("places all eight cleared activity photos on the appropriate public pages", async () => {
    const { activityPhotos } = await import("./photos");
    const rendered = {
      home: render("/").html,
      about: render("/about").html,
      programs: render("/programs").html,
      partner: render("/partner").html,
    };
    expect(rendered.home).toContain(homepageHeroImage.src);
    for (const photo of [
      activityPhotos.welcome,
      activityPhotos.community,
      activityPhotos.pride,
    ])
      expect(rendered.about).toContain(photo.src);
    for (const photo of [
      activityPhotos.solidarity,
      activityPhotos.advocacy,
      activityPhotos.outreach,
    ])
      expect(rendered.programs).toContain(photo.src);
    for (const photo of [activityPhotos.connections, activityPhotos.exchange])
      expect(rendered.partner).toContain(photo.src);
    expect(
      Object.values(activityPhotos)
        .map(photo => photo.sourceNumber)
        .sort((a, b) => a - b)
    ).toEqual([1, 2, 3, 4, 5, 6, 7, 9]);
    expect(rendered.home).toContain("photo-hero reference-home-hero");
    expect(rendered.home).not.toContain(
      "Illustrative artwork · identities protected"
    );
  });
  it("records consented-photo handling without inferring endorsements or exposing names and locations", () => {
    const { html } = render("/privacy");
    expect(html).toContain("participant consent");
    expect(html).toContain("safety clearance");
    expect(html).toContain("Embedded image metadata is omitted");
    expect(html).toContain("formal partnership or endorsement");
    expect(html).toContain("Captions do not disclose");
    expect(html).not.toContain("Illustrative artwork");
  });
});

describe("Official organization logo", () => {
  it("uses the supplied official mark across all public page headers and footers", async () => {
    const { branding } = await import("./branding");
    for (const route of routes) {
      const { html, head } = render(route.path);
      expect(
        html.split(`src="${branding.mark}"`).length - 1
      ).toBeGreaterThanOrEqual(2);
      expect(html).not.toContain('viewBox="0 0 56 56"');
      expect(head).toContain(branding.publicMark);
      expect(head).toContain('property="og:image:type" content="image/png"');
      expect(head).toContain('name="twitter:image:alt"');
      expect(head).not.toContain("IDhdGFooEPoYpIoM.svg");
    }
    expect(render("/about").html).toContain(branding.fullLogo);
    expect(render("/about").html).toContain(
      "Official Harbor of Hope Refugee Support Initiative logo"
    );
  });
});

describe("Organization identity and public-document removal", () => {
  it("removes the profile download and source-document references from every public page", () => {
    for (const route of routes) {
      const { html, head } = render(route.path);
      expect(html + head).not.toMatch(
        /organization profile|\.docx|Organization_Profile/i
      );
    }
  });
  it("describes refugee-led organizational leadership without community-led claims", () => {
    for (const route of routes) {
      const { html, head } = render(route.path);
      expect(html).toContain("Refugee-led organization");
      expect(html + head).not.toMatch(
        /community[- ]led|led by our community|community-rooted/i
      );
    }
    expect(
      programs.find(program => program.id === "community-outreach")!.details
    ).toContain("Our refugee-led organization");
    expect(render("/about").html).toContain(
      "Our organization is led by refugees"
    );
  });
  it("uses the supplied homepage image without adding generated-asset endpoints", () => {
    expect(render("/").html).toContain(
      'class="photo-hero reference-home-hero"'
    );
    expect(render("/").html).toContain("Safety is a beginning.");
    for (const route of routes) {
      expect(render(route.path).html).not.toMatch(
        /\/async-images\/|AI-generated|Illustrative artwork/
      );
    }
  });
});
