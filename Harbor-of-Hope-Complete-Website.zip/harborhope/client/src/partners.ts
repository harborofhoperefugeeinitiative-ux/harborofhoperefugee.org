// Organizations identified by Harbor of Hope as partners and donors.
// Specific funding roles and website links were not supplied and are not inferred.
export const partnersAndDonors = [
  {
    id: "hrapf",
    name: "Human Rights Awareness and Promotion Forum",
    shortName: "HRAPF",
    logo: "/manus-storage/hrapf_d85858be.webp",
    width: 1280,
    height: 672,
  },
  {
    id: "ucaa-ug",
    name: "Universal Coalition of Affirming Africans Uganda",
    shortName: "UCAA-UG",
    logo: "/manus-storage/ucaa-ug_11835c39.webp",
    width: 894,
    height: 235,
  },
  {
    id: "rainbow-railroad",
    name: "Rainbow Railroad",
    shortName: "",
    logo: "/manus-storage/rainbow-railroad_025bacde.webp",
    width: 736,
    height: 180,
  },
  {
    id: "international-pride-centre",
    name: "The International Pride Centre",
    shortName: "",
    logo: "/manus-storage/international-pride-centre_9d2a1eb8.webp",
    width: 1010,
    height: 435,
  },
] as const;
