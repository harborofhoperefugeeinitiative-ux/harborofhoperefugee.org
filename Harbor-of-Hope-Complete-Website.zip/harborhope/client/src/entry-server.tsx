import { renderToString } from "react-dom/server";
import App from "./App";
import { organization, routeFor } from "./content";
import { branding } from "./branding";

const shareImage = branding.publicMark;
export function escapeHtml(value: string) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}
export function render(path: string) {
  const cleanPath = path.length > 1 ? path.replace(/\/$/, "") : path;
  const route = routeFor(cleanPath);
  const title =
    route?.title || "Page Not Found | Harbor of Hope Refugee Support";
  const description =
    route?.description ||
    "This page could not be found. Return to Harbor of Hope's homepage or explore help and support information.";
  const head = `<title>${escapeHtml(title)}</title>
<meta name="description" content="${escapeHtml(description)}"/>
<meta name="keywords" content="Harbor of Hope, refugee-led, LGBTQ+ refugees, Uganda, refugee support"/>
<meta property="og:type" content="website"/>
<meta property="og:site_name" content="${escapeHtml(organization.name)}"/>
<meta property="og:title" content="${escapeHtml(title)}"/>
<meta property="og:description" content="${escapeHtml(description)}"/>
<meta property="og:image" content="${shareImage}"/>
<meta property="og:image:type" content="image/png"/>
<meta property="og:image:width" content="512"/>
<meta property="og:image:height" content="512"/>
<meta property="og:image:alt" content="Official Harbor of Hope Refugee Support Initiative logo"/>
<meta name="twitter:card" content="summary"/>
<meta name="twitter:title" content="${escapeHtml(title)}"/>
<meta name="twitter:description" content="${escapeHtml(description)}"/>
<meta name="twitter:image" content="${shareImage}"/>
<meta name="twitter:image:alt" content="Official Harbor of Hope Refugee Support Initiative logo"/>
${!route ? '<meta name="robots" content="noindex"/>' : ""}`;
  return {
    html: renderToString(<App initialPath={cleanPath} />),
    head,
    status: route ? 200 : 404,
  };
}
export function fillDocument(template: string, path: string) {
  const { html, head, status } = render(path);
  return {
    html: template
      .replace("<!--app-head-->", head)
      .replace("<!--app-html-->", html),
    status,
  };
}
