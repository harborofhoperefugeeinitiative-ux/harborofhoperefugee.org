import { useEffect, useState, type FormEvent } from "react";
import { organization, programs } from "../../content";
import ReferenceContactFields from "./ReferenceContactFields";
import { siteOrigin } from "../../siteConfig";

export const contactFormEndpoint = `https://formsubmit.co/${organization.email}`;
export const publishedContactUrl = `${siteOrigin}/contact`;

export function contactPageUrl(href?: string) {
  try {
    const url = new URL(href || publishedContactUrl);
    if (!["https:", "http:"].includes(url.protocol)) return publishedContactUrl;
    return `${url.origin}/contact`;
  } catch {
    return publishedContactUrl;
  }
}

export default function ContactForm() {
  const [topic, setTopic] = useState("");
  const [program, setProgram] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [pageUrl, setPageUrl] = useState(publishedContactUrl);
  useEffect(() => {
    setPageUrl(contactPageUrl(window.location.href));
    const params = new URLSearchParams(window.location.search);
    const initialTopic = params.get("topic");
    if (initialTopic)
      setTopic(initialTopic.replace(/[\r\n]/g, " ").slice(0, 120));
    const selected = programs.find(item => item.id === params.get("program"));
    if (selected) setProgram(selected.title);
  }, []);
  function submit(event: FormEvent<HTMLFormElement>) {
    for (const name of ["firstName", "lastName"]) {
      const field = event.currentTarget.elements.namedItem(
        name
      ) as HTMLInputElement;
      if (!field.value.trim()) {
        event.preventDefault();
        field.setCustomValidity("Please enter a name or alias.");
        field.reportValidity();
        return;
      }
    }
    const source = event.currentTarget.elements.namedItem(
      "_url"
    ) as HTMLInputElement;
    source.value = contactPageUrl(window.location.href);
    setSubmitting(true);
  }
  return (
    <div className="inquiry-form-wrap reference-contact-form">
      <form
        action={contactFormEndpoint}
        method="POST"
        onSubmit={submit}
        onChange={event => {
          if (event.target instanceof HTMLInputElement)
            event.target.setCustomValidity("");
        }}
      >
        <ReferenceContactFields
          topic={topic}
          setTopic={setTopic}
          emailFieldName="email"
        />
        <input type="hidden" name="_url" value={pageUrl} />
        <input
          type="hidden"
          name="_subject"
          value={`Harbor of Hope website — ${topic.replace(/[\r\n]/g, " ").trim() || "Contact inquiry"}`}
        />
        <input type="hidden" name="_template" value="table" />
        {program && (
          <>
            <p className="reference-form-note">
              <strong>Program area:</strong> {program}
            </p>
            <input type="hidden" name="Program area" value={program} />
          </>
        )}
        <div className="contact-honeypot" aria-hidden="true">
          <label htmlFor="contact-website">Leave this field empty</label>
          <input
            id="contact-website"
            name="_honey"
            type="text"
            tabIndex={-1}
            autoComplete="off"
          />
        </div>
        <button
          className="reference-submit"
          type="submit"
          disabled={submitting}
        >
          {submitting ? "Continuing…" : "Submit"}
        </button>
        <noscript>
          <p className="reference-form-note">
            This form also works without JavaScript. FormSubmit will show the
            submission result on its website.
          </p>
        </noscript>
      </form>
    </div>
  );
}
