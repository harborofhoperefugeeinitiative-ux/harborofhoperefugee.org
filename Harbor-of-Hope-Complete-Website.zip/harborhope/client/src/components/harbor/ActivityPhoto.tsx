import type { ActivityPhotoData } from "../../photos";

export default function ActivityPhoto({
  photo,
  className = "",
}: {
  photo: ActivityPhotoData;
  className?: string;
}) {
  return (
    <figure className={`activity-photo ${className}`}>
      <img
        src={photo.src}
        alt={photo.alt}
        width={photo.width}
        height={photo.height}
        loading="lazy"
        decoding="async"
      />
      <figcaption>
        <span>{photo.caption}</span>
      </figcaption>
    </figure>
  );
}
