import { conferencePhoto } from "../../conference";
import ActivityPhoto from "./ActivityPhoto";
import { Eyebrow } from "./Layout";

export default function ConferenceFeature() {
  return (
    <section
      className="section shell conference-feature"
      id="leadership-in-action"
      aria-labelledby="conference-feature-title"
    >
      <div className="conference-copy">
        <Eyebrow>LEADERSHIP IN ACTION</Eyebrow>
        <h2 id="conference-feature-title">
          Working toward meaningful community impact
        </h2>
        <p>
          Through conferences and workshop participation, Harbor of Hope seeks
          to bring the needs of LGBTQ+ refugees into wider conversations about
          protection and inclusion.
        </p>
        <p>
          In March 2026, our Executive Director participated in a workshop,
          <em> LGBTQ+ INCLUSION IN HUMANITARIAN RESPONSE</em>, held in Kenya.
        </p>
        <p>
          This engagement reflects Harbor of Hope’s commitment to supporting,
          protecting, and empowering LGBTQ+ refugees and asylum seekers in
          Uganda.
        </p>
      </div>
      <ActivityPhoto photo={conferencePhoto} className="conference-photo" />
    </section>
  );
}
