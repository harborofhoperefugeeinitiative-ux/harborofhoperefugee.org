import { useEffect, useState, type FormEvent } from "react";
import { ArrowUpRight, Check, Copy, LockKeyhole, Mail } from "lucide-react";
import { organization, programs } from "../../content";
import ReferenceContactFields, {
  buildReferenceInquiry,
} from "./ReferenceContactFields";

export const inquiryTopics = [
  "General inquiry",
  "Partnership",
  "Support our work",
  "Volunteering",
  "Technical support & training",
  "Support request",
  "Safeguarding concern",
];

export function buildInquiry({
  topic,
  name,
  reply,
  message,
  program,
}: {
  topic: string;
  name: string;
  reply: string;
  message: string;
  program?: string;
}) {
  const subject = `Harbor of Hope — ${topic}`;
  const body = [
    `Hello Harbor of Hope,`,
    "",
    `Inquiry: ${topic}`,
    program ? `Program area: ${program}` : "",
    name.trim() ? `Name / alias: ${name.trim()}` : "",
    `Safe reply email: ${reply.trim()}`,
    "",
    message.trim(),
    "",
    "Please use the reply email above for this inquiry.",
  ]
    .filter(
      (line, index, all) => line !== "" || (index > 0 && all[index - 1] !== "")
    )
    .join("\n");
  return {
    subject,
    body,
    mailto: `mailto:${organization.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`,
  };
}

export default function InquiryForm({
  support = false,
  reference = false,
}: {
  support?: boolean;
  reference?: boolean;
}) {
  const [topic, setTopic] = useState(
    support ? "Support request" : reference ? "" : "General inquiry"
  );
  const [draft, setDraft] = useState<ReturnType<typeof buildInquiry> | null>(
    null
  );
  const [copied, setCopied] = useState(false);
  const [copyError, setCopyError] = useState(false);
  const [program, setProgram] = useState("");
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const value = params.get("topic");
    if (value && inquiryTopics.includes(value)) setTopic(value);
    const area = programs.find(item => item.id === params.get("program"));
    if (area && !support) setProgram(area.title);
  }, []);
  function prepare(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const message = String(data.get("message") || "");
    const field = event.currentTarget.elements.namedItem(
      "message"
    ) as HTMLTextAreaElement;
    if (reference) {
      for (const name of ["firstName", "lastName"]) {
        const input = event.currentTarget.elements.namedItem(
          name
        ) as HTMLInputElement;
        if (!input.value.trim()) {
          input.setCustomValidity("Please enter a name or alias.");
          input.reportValidity();
          return;
        }
      }
    }
    if (!reference && message.trim().length < 10) {
      field.setCustomValidity(
        "Please write a brief message of at least 10 non-blank characters."
      );
      field.reportValidity();
      return;
    }
    setDraft(
      reference
        ? buildReferenceInquiry(data, program)
        : buildInquiry({
            topic,
            name: String(data.get("name") || ""),
            reply: String(data.get("reply") || ""),
            message,
            program,
          })
    );
    setCopied(false);
    setCopyError(false);
  }
  async function copy() {
    if (!draft) return;
    try {
      await navigator.clipboard.writeText(
        `To: ${organization.email}\nSubject: ${draft.subject}\n\n${draft.body}`
      );
      setCopied(true);
      setCopyError(false);
    } catch {
      setCopyError(true);
    }
  }
  return (
    <div
      className={
        reference
          ? "inquiry-form-wrap reference-contact-form"
          : "inquiry-form-wrap"
      }
    >
      {!reference && (
        <>
          <div className="form-heading">
            <span className="icon-tile lavender">
              <Mail size={24} />
            </span>
            <div>
              <h2>
                {support
                  ? "Make a careful initial inquiry"
                  : "Start a conversation"}
              </h2>
              <p>A small first step. Only share what feels safe.</p>
            </div>
          </div>
          <div className="form-privacy">
            <LockKeyhole size={16} />
            <p>
              This form prepares an email draft on your device. It does not send
              or save your message on this website. You review and send it in
              your email app.
            </p>
          </div>
        </>
      )}
      {program && (
        <p className="field-help">
          <strong>Program area:</strong> {program}
        </p>
      )}
      <form
        onSubmit={prepare}
        onChange={event => {
          setDraft(null);
          if (
            event.target instanceof HTMLTextAreaElement ||
            event.target instanceof HTMLInputElement
          )
            event.target.setCustomValidity("");
        }}
      >
        {reference ? (
          <ReferenceContactFields topic={topic} setTopic={setTopic} />
        ) : (
          <>
            {!support && (
              <div className="field">
                <label htmlFor="topic">What would you like to discuss?</label>
                <select
                  id="topic"
                  name="topic"
                  value={topic}
                  onChange={event => setTopic(event.target.value)}
                >
                  {inquiryTopics.map(item => (
                    <option key={item}>{item}</option>
                  ))}
                </select>
              </div>
            )}
            <div className="form-row">
              <div className="field">
                <label htmlFor="name">
                  Name or alias <span>(optional)</span>
                </label>
                <input
                  id="name"
                  name="name"
                  maxLength={80}
                  placeholder="How should we address you?"
                  autoComplete="off"
                />
              </div>
              <div className="field">
                <label htmlFor="reply">
                  Safe reply email <span>(required)</span>
                </label>
                <input
                  id="reply"
                  name="reply"
                  type="email"
                  maxLength={254}
                  required
                  placeholder="An email you can safely access"
                  autoComplete="off"
                  aria-describedby="reply-help"
                />
              </div>
            </div>
            <p className="field-help" id="reply-help">
              Choose an inbox where receiving a response will not put you at
              risk.
            </p>
            <div className="field">
              <label htmlFor="message">
                Brief message <span>(required)</span>
              </label>
              <textarea
                id="message"
                name="message"
                required
                minLength={10}
                maxLength={1200}
                rows={5}
                placeholder={
                  support
                    ? "Briefly describe the type of support or referral you are asking about. No private case details are needed."
                    : "Tell us briefly how you would like to connect."
                }
                aria-describedby="message-help"
              />
              <p className="field-help" id="message-help">
                Please do not include identity documents, health records, exact
                locations, names of other people, or sensitive case details.
                Maximum 1,200 characters.
              </p>
            </div>
            <label className="consent-label">
              <input type="checkbox" name="consent" required />
              <span>
                I understand that this creates a draft, not a sent message. I
                choose to share this inquiry by email so Harbor of Hope can
                consider it and reply. I have read the{" "}
                <a href="/privacy">privacy and safety guidance</a>.
              </span>
            </label>
            <button className="button button-primary" type="submit">
              Prepare email draft <ArrowUpRight size={18} />
            </button>
            <p className="form-expectation">
              Not an emergency service. Assistance and response times depend on
              resources and capacity.
            </p>
          </>
        )}
        {reference && (
          <>
            <button className="reference-submit" type="submit">
              Submit
            </button>
            <p className="reference-form-note" id="contact-form-note">
              Submit prepares an email draft for you to review and send. It does
              not send or save your message on this website. Required fields are
              marked *. You may use an alias. Please share only necessary
              information, up to 1,200 characters.
            </p>
            <p className="reference-form-note">
              By preparing a draft, you choose to share your inquiry by email so
              Harbor of Hope can consider it and reply. Read our{" "}
              <a href="/privacy">privacy and safety guidance</a>.
            </p>
          </>
        )}
      </form>
      {draft && (
        <div className="draft-result" role="status">
          <div className="draft-title">
            <Check size={20} />
            <strong>Your draft is ready — it has not been sent.</strong>
          </div>
          <p>
            Open your email app, review the message, and send it when you are
            comfortable. Email uses third-party services; no online channel can
            guarantee complete confidentiality.
          </p>
          <div className="actions">
            <a className="button button-primary" href={draft.mailto}>
              Open email app <ArrowUpRight size={16} />
            </a>
            <button
              className="button button-outline"
              type="button"
              onClick={copy}
            >
              {copied ? <Check size={16} /> : <Copy size={16} />}{" "}
              {copied ? "Copied" : "Copy inquiry"}
            </button>
          </div>
          {copied && (
            <p className="field-help">
              Copied to your clipboard. Avoid copying sensitive information on a
              shared device.
            </p>
          )}
          {copyError && (
            <p className="field-help">
              Clipboard access is unavailable. Select and copy the draft below
              instead.
            </p>
          )}
          <details>
            <summary>Review your prepared draft</summary>
            <p className="field-help">To: {organization.email}</p>
            <textarea
              className="draft-preview"
              readOnly
              value={`Subject: ${draft.subject}\n\n${draft.body}`}
              aria-label="Prepared email draft"
              rows={9}
            />
          </details>
          <button
            type="button"
            className="clear-draft"
            onClick={() => {
              setDraft(null);
              const form = document.querySelector<HTMLFormElement>(
                ".inquiry-form-wrap form"
              );
              form?.reset();
              if (reference) setTopic("");
            }}
          >
            Clear form and draft
          </button>
        </div>
      )}
    </div>
  );
}
