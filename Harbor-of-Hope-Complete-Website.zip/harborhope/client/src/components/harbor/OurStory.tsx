import { ourStory } from "../../story";
import { Eyebrow } from "./Layout";

export default function OurStory() {
  return (
    <section className="story-chapters-section">
      <div className="shell story-chapters-layout">
        <aside className="story-chapter-nav">
          <Eyebrow>IN OUR OWN WORDS</Eyebrow>
          <nav aria-label="Explore our story">
            {ourStory.chapters.map(chapter => (
              <a key={chapter.id} href={`#${chapter.id}`}>
                {chapter.title}
              </a>
            ))}
          </nav>
        </aside>
        <article className="story-chapters" aria-label="Our story continued">
          {ourStory.chapters.map(chapter => (
            <section
              id={chapter.id}
              key={chapter.id}
              aria-labelledby={`${chapter.id}-title`}
            >
              <h3 id={`${chapter.id}-title`}>{chapter.title}</h3>
              {chapter.paragraphs.map(paragraph => (
                <p key={paragraph}>{paragraph}</p>
              ))}
            </section>
          ))}
          <div className="story-signature">
            <strong>{ourStory.signature}</strong>
            <p>{ourStory.tagline}</p>
          </div>
        </article>
      </div>
    </section>
  );
}
