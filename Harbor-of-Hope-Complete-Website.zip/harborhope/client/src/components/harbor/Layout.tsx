import { useEffect, useState } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  Menu,
  X,
  ShieldCheck,
  MapPin,
  Mail,
  Phone,
  ExternalLink,
} from "lucide-react";
import { organization, routeFor } from "../../content";
import { branding } from "../../branding";
import type { ActivityPhotoData } from "../../photos";
import PhotoHero from "./PhotoHero";

export function BrandMark({ className = "" }: { className?: string }) {
  return (
    <img
      className={className}
      src={branding.mark}
      alt=""
      width={512}
      height={512}
      aria-hidden="true"
    />
  );
}

export function Brand({ light = false }: { light?: boolean }) {
  return (
    <a
      href="/"
      className={`brand ${light ? "brand-light" : ""}`}
      aria-label="Harbor of Hope home"
    >
      <BrandMark className="brand-mark" />
      <span>
        <strong>Harbor of Hope</strong>
        <small>REFUGEE SUPPORT INITIATIVE</small>
      </span>
    </a>
  );
}

const links = [
  ["/", "Home"],
  ["/about", "About Us"],
  ["/programs", "Programs & Services"],
  ["/#why-it-matters", "Our Impact"],
  ["/get-support", "Get Support"],
  ["/partner", "Get involved"],
  ["/contact", "Contact"],
];

export function Header({ path }: { path: string }) {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    function escape(event: KeyboardEvent) {
      if (event.key === "Escape") setOpen(false);
    }
    window.addEventListener("keydown", escape);
    return () => window.removeEventListener("keydown", escape);
  }, []);
  return (
    <div
      className={`navigation-frame ${routeFor(path) ? "hero-navigation" : ""}`}
    >
      <div className="utility-bar">
        <div className="shell utility-inner">
          <span>
            <span className="status-dot" /> Refugee-led organization · Uganda
          </span>
          <div>
            <a href="/get-support">
              Looking for support? <ArrowUpRight size={13} />
            </a>
            <span className="utility-divider" />
            <a
              href="https://www.google.com"
              className="quick-exit"
              title="Leave this site. This does not clear browsing history."
              rel="noreferrer"
            >
              Quick exit <ExternalLink size={12} />
            </a>
          </div>
        </div>
      </div>
      <header className="site-header">
        <div className="shell header-inner">
          <Brand />
          <nav className="desktop-nav" aria-label="Main navigation">
            {links.map(([href, label]) => (
              <a
                key={href}
                href={href}
                aria-current={path === href ? "page" : undefined}
              >
                {label}
              </a>
            ))}
          </nav>
          <DonationLink className="button button-primary header-cta">
            Donate
          </DonationLink>
          <button
            className="menu-toggle"
            onClick={() => setOpen(!open)}
            aria-label={open ? "Close navigation" : "Open navigation"}
            aria-expanded={open}
            aria-controls={open ? "mobile-nav" : undefined}
          >
            {open ? <X /> : <Menu />}
          </button>
        </div>
        {open && (
          <nav
            id="mobile-nav"
            className="mobile-nav"
            aria-label="Mobile navigation"
          >
            {links.map(([href, label]) => (
              <a
                key={href}
                href={href}
                aria-current={path === href ? "page" : undefined}
              >
                {label}
                <ArrowUpRight size={18} />
              </a>
            ))}
            <DonationLink className="button button-primary">
              Donate on Spotfund
            </DonationLink>
          </nav>
        )}
      </header>
    </div>
  );
}

export function DonationLink({
  children = "Donate on Spotfund",
  className = "button button-primary",
}: {
  children?: React.ReactNode;
  className?: string;
}) {
  return (
    <a
      href={organization.donationUrl}
      className={className}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Donate to Harbor of Hope on Spotfund (opens in a new tab)"
      title="Opens Spotfund in a new tab"
    >
      {children}
      <ArrowUpRight size={18} aria-hidden="true" />
    </a>
  );
}

export function ButtonLink({
  href,
  children,
  kind = "primary",
  arrow = true,
}: {
  href: string;
  children: React.ReactNode;
  kind?: string;
  arrow?: boolean;
}) {
  return (
    <a className={`button button-${kind}`} href={href}>
      {children}
      {arrow && <ArrowUpRight size={18} />}
    </a>
  );
}
export function TextLink({
  href,
  children,
}: {
  href: string;
  children: React.ReactNode;
}) {
  return (
    <a className="text-link" href={href}>
      {children}
      <ArrowRight size={18} />
    </a>
  );
}
export function Eyebrow({
  children,
  light = false,
}: {
  children: React.ReactNode;
  light?: boolean;
}) {
  return (
    <div className={`eyebrow ${light ? "eyebrow-light" : ""}`}>
      <span />
      {children}
    </div>
  );
}
export function PageIntro({
  eyebrow,
  title,
  text,
  photo,
}: {
  eyebrow: string;
  title: React.ReactNode;
  text: string;
  photo: ActivityPhotoData;
}) {
  return (
    <PhotoHero photo={photo} eyebrow={eyebrow} title={title} text={text} />
  );
}
export function SafetyNote({ children }: { children?: React.ReactNode }) {
  return (
    <aside className="safety-note">
      <ShieldCheck size={22} />
      <div>
        <strong>Your safety comes first.</strong>
        <p>
          {children ||
            "Assistance and referrals depend on available resources and capacity. Please do not share sensitive case details, identification documents, or private addresses in an initial inquiry."}
        </p>
      </div>
    </aside>
  );
}
export function PartnerBanner() {
  return (
    <section className="partner-banner shell">
      <div className="partner-banner-content">
        <Eyebrow light>PARTNERSHIPS & SUPPORT</Eyebrow>
        <h2>Work with Harbor of Hope.</h2>
        <p>
          Resources, expertise, and responsible partnerships help our
          refugee-led organization strengthen protection and opportunities for
          LGBTQ+ refugees.
        </p>
        <div className="actions">
          <DonationLink className="button button-coral" />
          <ButtonLink href="/partner" kind="lime">
            Explore other ways to support
          </ButtonLink>
        </div>
        <p className="field-help">
          Donations are completed on Spotfund, an external fundraising platform.
        </p>
      </div>
      <BrandMark className="banner-mark" />
    </section>
  );
}
export function Footer() {
  return (
    <footer className="site-footer">
      <div className="shell footer-grid">
        <div className="footer-about">
          <Brand light />
          <p>
            Care. Protect. Empower.
            <br />
            Together, We Bring Hope.
          </p>
          <span className="footer-place">
            <MapPin size={15} /> Refugee-led organization in Uganda
          </span>
        </div>
        <div>
          <h3>Explore</h3>
          <a href="/">Home</a>
          <a href="/about">About Us</a>
          <a href="/programs">Our programs</a>
          <a href="/partner">Partner with us</a>
          <a href="/get-support">Help & support</a>
          <DonationLink className="footer-donation">
            Donate on Spotfund
          </DonationLink>
        </div>
        <div>
          <h3>Our commitments</h3>
          <a href="/privacy">Privacy & safeguarding</a>
          <a href="/contact?topic=Safeguarding%20concern">Raise a concern</a>
        </div>
        <div className="footer-contact">
          <h3>Let's connect</h3>
          <a href={`mailto:${organization.email}`}>
            <Mail size={16} />
            <span>{organization.email}</span>
          </a>
          <a href={organization.phoneLink}>
            <Phone size={16} />
            {organization.phone}
          </a>
          <p>{organization.address}</p>
        </div>
      </div>
      <div className="shell footer-bottom">
        <span>
          © {new Date().getFullYear()} Harbor of Hope Refugee Support
          Initiative
        </span>
        <a href="/privacy">Privacy & safety</a>
      </div>
    </footer>
  );
}
