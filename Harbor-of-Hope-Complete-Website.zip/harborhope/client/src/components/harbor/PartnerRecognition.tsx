import { partnersAndDonors } from "../../partners";
import { Eyebrow } from "./Layout";

export default function PartnerRecognition() {
  return (
    <section
      className="partner-recognition"
      aria-labelledby="partners-donors-title"
      id="partners-donors"
    >
      <div className="shell section">
        <div className="recognition-heading">
          <div>
            <Eyebrow>WITH APPRECIATION</Eyebrow>
            <h2 id="partners-donors-title">Our partners &amp; donors</h2>
          </div>
          <p>
            We thank the organizations that partner with and support Harbor of
            Hope.
          </p>
        </div>
        <ul className="recognition-list">
          {partnersAndDonors.map(partner => (
            <li key={partner.id} className="recognition-item">
              <div className="recognition-logo">
                <img
                  src={partner.logo}
                  alt={`${partner.name}${partner.shortName ? ` (${partner.shortName})` : ""} logo`}
                  width={partner.width}
                  height={partner.height}
                  loading="lazy"
                  decoding="async"
                />
              </div>
              <div className="recognition-name">
                {partner.shortName && <span>{partner.shortName}</span>}
                <h3>{partner.name}</h3>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
