import type { ReactNode } from "react";
import type { ActivityPhotoData } from "../../photos";

export default function PhotoHero({
  photo,
  eyebrow,
  title,
  text,
  children,
  home = false,
}: {
  photo: Pick<ActivityPhotoData, "src" | "width" | "height" | "alt">;
  eyebrow: string;
  title: ReactNode;
  text: string;
  children?: ReactNode;
  home?: boolean;
}) {
  return (
    <section
      className={`photo-hero ${home ? "reference-home-hero" : "inner-photo-hero"}`}
    >
      <div className="photo-hero-media">
        <img
          className="photo-hero-image"
          src={photo.src}
          alt={photo.alt}
          width={photo.width}
          height={photo.height}
          fetchPriority="high"
          decoding="async"
        />
      </div>
      <div className="photo-hero-shade" aria-hidden="true" />
      <div className="shell photo-hero-content">
        {!home && (
          <nav className="photo-hero-breadcrumb" aria-label="Breadcrumb">
            <a href="/">Home</a>
            <span aria-hidden="true">/</span>
            <span>{eyebrow}</span>
          </nav>
        )}
        <div className="photo-hero-eyebrow">
          <span aria-hidden="true" />
          {eyebrow}
        </div>
        <h1>{title}</h1>
        <p className="photo-hero-description">{text}</p>
        {children}
      </div>
      {home && (
        <div className="photo-hero-note">
          Care. Protect. Empower.
          <br />
          Together, We Bring Hope.
        </div>
      )}
    </section>
  );
}
