import { buildInquiry } from "./InquiryForm";

export function buildReferenceInquiry(data: FormData, program = "") {
  return buildInquiry({
    topic: String(data.get("topic") || "").trim() || "General inquiry",
    name: [data.get("firstName"), data.get("lastName")]
      .map(value => String(value || "").trim())
      .filter(Boolean)
      .join(" "),
    reply: String(data.get("reply") || ""),
    message: String(data.get("message") || ""),
    program,
  });
}

export default function ReferenceContactFields({
  topic,
  setTopic,
  emailFieldName = "reply",
}: {
  topic: string;
  setTopic: (value: string) => void;
  emailFieldName?: "reply" | "email";
}) {
  return (
    <>
      <fieldset className="reference-name-field">
        <legend>
          Name{" "}
          <span className="required-star" aria-hidden="true">
            *
          </span>
        </legend>
        <div className="reference-name-row">
          <div>
            <input
              id="first-name"
              name="firstName"
              required
              maxLength={80}
              autoComplete="off"
            />
            <label htmlFor="first-name">First</label>
          </div>
          <div>
            <input
              id="last-name"
              name="lastName"
              required
              maxLength={80}
              autoComplete="off"
            />
            <label htmlFor="last-name">Last</label>
          </div>
        </div>
      </fieldset>
      <div className="reference-field">
        <label htmlFor="reply">
          Email{" "}
          <span className="required-star" aria-hidden="true">
            *
          </span>
        </label>
        <input
          id="reply"
          name={emailFieldName}
          type="email"
          required
          maxLength={254}
          autoComplete="off"
        />
      </div>
      <div className="reference-field">
        <label htmlFor="topic">Subject</label>
        <input
          id="topic"
          name="topic"
          maxLength={120}
          value={topic}
          onChange={event => setTopic(event.target.value)}
          aria-label="Subject"
        />
      </div>
      <div className="reference-field">
        <label htmlFor="message">Comment or Message</label>
        <textarea id="message" name="message" rows={7} maxLength={1200} />
      </div>
    </>
  );
}
