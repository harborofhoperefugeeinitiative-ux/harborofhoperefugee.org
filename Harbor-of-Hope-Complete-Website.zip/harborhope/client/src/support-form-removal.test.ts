import { describe, expect, it } from "vitest";
import { render } from "./entry-server";
import { activityPhotos } from "./photos";
import { organization } from "./content";

describe("Pictured Get Support content removal", () => {
  it("removes the whole guidance/introduction/draft-form section", () => {
    const html = render("/get-support").html;
    for (const text of [
      "Keep your inquiry brief",
      "Set realistic expectations",
      "A CAREFUL FIRST STEP",
      "Make a careful initial inquiry",
      "A small first step",
      "This form prepares an email draft",
      "Name or alias",
      "Safe reply email",
      "Brief message",
      "Prepare email draft",
      "Read our privacy &amp; safety guidance",
    ]) {
      expect(html).not.toContain(text);
    }
    expect(html).not.toMatch(
      /<form|<textarea|name="consent"|support-form-layout|support-steps/
    );
    expect(html).toContain(activityPhotos.solidarity.src);
    expect(html).not.toContain("Before you contact us");
    expect(html).toContain('href="/contact?topic=Support%20request"');
  });
  it("preserves the working contact form and truthful provider disclosures", () => {
    const contact = render("/contact").html;
    expect(contact).toContain(
      `action="https://formsubmit.co/${organization.email}"`
    );
    expect(contact).toContain('name="_url"');
    expect(contact).toContain('name="email"');
    expect(contact).toContain(">Submit</button>");
    const privacy = render("/privacy").html;
    expect(privacy).toContain("does not have a separate inquiry form");
    expect(privacy).toContain("30 days");
    expect(privacy).not.toMatch(
      /Get Support form|With Get Support, you can review the draft/
    );
  });
});
