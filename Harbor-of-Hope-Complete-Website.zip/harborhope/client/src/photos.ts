export type ActivityPhotoData = {
  sourceNumber: number;
  src: string;
  width: number;
  height: number;
  alt: string;
  caption: string;
};

// Usage permission, participant consent, safety clearance, and activity context
// were explicitly confirmed by the organization in this conversation.
// No participant names, dates, exact locations, or partner identities are inferred.
export const activityPhotos = {
  welcome: {
    sourceNumber: 1,
    src: "/manus-storage/harbor-activity-1_e2399dff.webp",
    width: 1280,
    height: 954,
    alt: "A group gathered with rainbow and trans-inclusive Pride flags during a Harbor of Hope community activity",
    caption: "Our community. Our shared hope.",
  },
  connections: {
    sourceNumber: 2,
    src: "/manus-storage/harbor-activity-2_f69a4dbf.webp",
    width: 1280,
    height: 746,
    alt: "People gathered together during a Harbor of Hope community activity",
    caption: "Coming together. Building connections.",
  },
  solidarity: {
    sourceNumber: 3,
    src: "/manus-storage/harbor-activity-3_fa795390.webp",
    width: 1280,
    height: 858,
    alt: "Community members standing together behind a large rainbow Pride flag",
    caption: "Standing together as a community.",
  },
  pride: {
    sourceNumber: 4,
    src: "/manus-storage/harbor-activity-4_e722803b.webp",
    width: 1280,
    height: 856,
    alt: "A community group holding Pride flags during a Harbor of Hope activity",
    caption: "Gathering in solidarity.",
  },
  outreach: {
    sourceNumber: 5,
    src: "/manus-storage/harbor-activity-5_f643fcc1.webp",
    width: 1280,
    height: 840,
    alt: "People walking together with rainbow Pride flags during a community activity",
    caption: "Community participation. Shared visibility.",
  },
  community: {
    sourceNumber: 6,
    src: "/manus-storage/harbor-activity-6_3e6254b3.webp",
    width: 1280,
    height: 938,
    alt: "People standing together for a group photograph during a Harbor of Hope activity",
    caption: "Connection at the heart of our work.",
  },
  exchange: {
    sourceNumber: 7,
    src: "/manus-storage/harbor-activity-7_c9d7a129.webp",
    width: 1280,
    height: 948,
    alt: "Participants gathered around tables for discussion and exchange during a Harbor of Hope activity",
    caption: "Space for discussion and exchange.",
  },
  advocacy: {
    sourceNumber: 9,
    src: "/manus-storage/harbor-activity-9_2d7c92f9.webp",
    width: 1280,
    height: 932,
    alt: "People at a public advocacy gathering holding signs calling for LGBTQ+ rights and dignity",
    caption: "Standing for dignity and equal rights.",
  },
} satisfies Record<string, ActivityPhotoData>;
