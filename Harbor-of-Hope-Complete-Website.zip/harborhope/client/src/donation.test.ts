import { createElement } from "react";
import { describe, expect, it } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
import { render } from "./entry-server";
import { organization, routes } from "./content";
import { DonationLink } from "./components/harbor/Layout";

describe("Supplied Spotfund donation link", () => {
  it("uses the exact supplied URL with safe new-tab attributes and accessible destination labeling", () => {
    expect(organization.donationUrl).toBe("http://spot.fund/d8qhqnrsc");
    const html = renderToStaticMarkup(createElement(DonationLink));
    expect(html).toContain(`href="${organization.donationUrl}"`);
    expect(html).toContain('target="_blank"');
    expect(html).toContain('rel="noopener noreferrer"');
    expect(html).toContain("Spotfund (opens in a new tab)");
  });
  it("connects the shared header and footer on every page, plus homepage banners and the Partnerships support card", () => {
    for (const route of routes) {
      const html = render(route.path).html;
      expect(
        html.split(`href="${organization.donationUrl}"`).length - 1
      ).toBeGreaterThanOrEqual(2);
      expect(html).not.toContain('href="/partner#support"');
    }
    expect(
      render("/").html.split(`href="${organization.donationUrl}"`).length - 1
    ).toBeGreaterThanOrEqual(3);
    expect(render("/partner").html).toContain(
      "Donations are completed on Spotfund"
    );
    expect(render("/partner").html).toContain(
      "Discuss in-kind or other support"
    );
  });
  it("does not collect payment details or claim an on-site checkout", () => {
    const html = render("/privacy").html;
    expect(html).toContain("Donations through Spotfund");
    expect(html).toContain(
      "does not collect payment details or process the donation"
    );
    expect(html).not.toContain('name="card"');
    expect(html).not.toContain("stripe.com");
  });
});
