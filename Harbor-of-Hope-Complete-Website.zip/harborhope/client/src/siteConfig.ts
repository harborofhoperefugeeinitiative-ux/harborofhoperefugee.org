// VITE_SITE_URL is public build configuration, never a secret.
// Vite uses import.meta.env; the Node prerender step reads the same .env value.
const configuredUrl =
  import.meta.env?.VITE_SITE_URL ||
  (typeof process !== "undefined" ? process.env.VITE_SITE_URL : undefined);

function originFor(value?: string): string {
  if (!value?.trim()) return "http://localhost:3000";
  const url = new URL(value.trim());
  if (!["http:", "https:"].includes(url.protocol) || url.username || url.password) {
    throw new Error("VITE_SITE_URL must be an HTTP(S) site origin with no credentials.");
  }
  if (url.pathname !== "/" || url.search || url.hash) {
    throw new Error("VITE_SITE_URL must contain only the origin, not a path, query, or fragment.");
  }
  return url.origin;
}

export const siteOrigin = originFor(configuredUrl);
export function siteAssetUrl(assetPath: string): string {
  // Relative metadata is useful for local preview; configure the production
  // domain before publishing so social crawlers receive an absolute HTTPS URL.
  return configuredUrl ? new URL(assetPath, siteOrigin).href : assetPath;
}
