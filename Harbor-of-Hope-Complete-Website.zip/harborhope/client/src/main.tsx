import { createRoot, hydrateRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import "./styles/brand.css";
import "./styles/hero.css";

const root = document.getElementById("root")!;
if (root.children.length) hydrateRoot(root, <App />);
else createRoot(root).render(<App />);
