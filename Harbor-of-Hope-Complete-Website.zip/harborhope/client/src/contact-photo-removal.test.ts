import { describe, expect, it } from "vitest";
import { render } from "./entry-server";
import { organization, routes } from "./content";
import { activityPhotos } from "./photos";

describe("Photo supplier labels and WhatsApp channel removal", () => {
  it("removes supplier labels and WhatsApp references from all public pages and metadata", () => {
    expect(organization).not.toHaveProperty("whatsapp");
    for (const route of routes) {
      const { html, head } = render(route.path);
      expect(html + head).not.toMatch(
        /(?:Photo|Image) supplied by Harbor of Hope|whatsapp|wa\.me|api\.whatsapp/i
      );
      expect(html).toContain(organization.email);
      expect(html).toContain(organization.phoneLink);
      expect(html).toContain(organization.donationUrl);
    }
  });
  it("preserves activity photographs, descriptive captions, and alternative text", () => {
    const combined = ["/about", "/programs", "/partner"]
      .map(path => render(path).html)
      .join("");
    for (const photo of Object.values(activityPhotos)) {
      expect(combined).toContain(photo.src);
      expect(combined).toContain(photo.alt);
    }
    expect(render("/about").html).toContain(activityPhotos.community.caption);
    expect(render("/partner").html).toContain(activityPhotos.exchange.caption);
    expect(render("/").html).toContain(
      "Our focus: Uganda. Our commitment: dignity."
    );
    expect(render("/privacy").html).toContain("participant consent");
  });
  it("keeps the Contact Us form and telephone contacts available", () => {
    for (const path of ["/contact", "/get-support"]) {
      const { html } = render(path);
      if (path === "/contact") {
        expect(html).toContain(">Submit</button>");
        expect(html).toContain('name="email"');
      } else {
        expect(html).not.toContain("<form");
        expect(html).toContain('href="/contact?topic=Support%20request"');
      }
      expect(html).toContain(`href="${organization.phoneLink}"`);
    }
    expect(render("/get-support").html).not.toContain(
      "Is email completely confidential?"
    );
  });
});
