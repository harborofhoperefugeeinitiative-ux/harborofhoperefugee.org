import {
  ArrowUpRight,
  Heart,
  ShieldCheck,
  Users,
  MapPin,
  Sprout,
  House,
  HeartPulse,
  Check,
} from "lucide-react";
import { imagery, organization } from "../../content";
import { homepageHeroImage } from "../../homepageHero";
import PhotoHero from "../../components/harbor/PhotoHero";
import ConferenceFeature from "../../components/harbor/ConferenceFeature";
import {
  ButtonLink,
  Eyebrow,
  PartnerBanner,
  TextLink,
} from "../../components/harbor/Layout";

export default function Home() {
  return (
    <>
      <PhotoHero
        home
        photo={homepageHeroImage}
        eyebrow="REFUGEE-LED ORGANIZATION · SUPPORTING LGBTQ+ REFUGEES & ASYLUM SEEKERS"
        title={
          <>
            <span className="hero-line">Safety is a beginning.</span>
            <span className="hero-line hero-gold">Hope is a practice.</span>
          </>
        }
        text="Harbor of Hope supports LGBTQ+ refugees and asylum seekers in Uganda to move through crisis with dignity, connection, and real possibility."
      >
        <div className="photo-hero-actions">
          <ButtonLink href="/get-support" kind="coral">
            Get support
          </ButtonLink>
          <ButtonLink href="/about#our-approach" kind="hero-outline">
            How we work
          </ButtonLink>
        </div>
      </PhotoHero>
      <div className="trust-strip">
        <div className="shell trust-inner">
          <span>
            <Users size={21} />
            <strong>Refugee-led organization</strong>
            <small>Leadership informed by lived experience</small>
          </span>
          <span>
            <MapPin size={21} />
            <strong>Uganda-focused</strong>
            <small>
              Supporting LGBTQ+ refugees and asylum seekers in Uganda
            </small>
          </span>
          <span>
            <ShieldCheck size={21} />
            <strong>Protection-centered</strong>
            <small>Safety, dignity, and confidentiality</small>
          </span>
        </div>
      </div>
      <section className="section shell home-about">
        <div className="about-aside">
          <Eyebrow>WHO WE ARE</Eyebrow>
        </div>
        <div className="about-main">
          <h2>A refugee-led organization focused on dignity and protection.</h2>
          <div className="about-columns">
            <p>
              Harbor of Hope Refugee Support Initiative is a refugee-led
              organization working alongside LGBTQ+ refugees and asylum seekers
              in Uganda who face discrimination, violence, homelessness, and
              barriers to essential services.
            </p>
            <div>
              <p>
                We identify needs, connect LGBTQ+ refugees and asylum seekers
                with appropriate services, and seek resources and partnerships
                for practical assistance.
              </p>
              <TextLink href="/about#our-story">Read our story</TextLink>
            </div>
          </div>
        </div>
      </section>
      <section className="programs-section">
        <div className="shell">
          <div className="section-heading">
            <div>
              <Eyebrow>OUR WORK</Eyebrow>
              <h2>Protection, care, and opportunity.</h2>
            </div>
            <div className="section-heading-right">
              <p>Eight areas of work support our mission.</p>
              <TextLink href="/programs">View all eight programs</TextLink>
            </div>
          </div>
          <div className="feature-programs">
            <a href="/programs#safe-shelter" className="feature-card lavender">
              <div className="card-top">
                <span className="icon-tile">
                  <House size={27} />
                </span>
                <span className="category">PROTECT</span>
              </div>
              <h3>Protection and shelter</h3>
              <p>
                Safe shelter coordination, emergency protection, and referrals
                for people facing heightened risks.
              </p>
              <span className="card-link">
                Explore this area <ArrowUpRight size={22} />
              </span>
            </a>
            <a href="/programs#health-access" className="feature-card peach">
              <div className="card-top">
                <span className="icon-tile">
                  <HeartPulse size={27} />
                </span>
                <span className="category">CARE</span>
              </div>
              <h3>Health and well-being</h3>
              <p>
                Connections to appropriate healthcare, psychosocial support, and
                essential services.
              </p>
              <span className="card-link">
                Explore this area <ArrowUpRight size={22} />
              </span>
            </a>
            <a href="/programs#livelihoods" className="feature-card green">
              <div className="card-top">
                <span className="icon-tile">
                  <Sprout size={27} />
                </span>
                <span className="category">EMPOWER</span>
              </div>
              <h3>Livelihoods and skills</h3>
              <p>
                Digital skills, vocational learning, and livelihood
                opportunities that strengthen independence.
              </p>
              <span className="card-link">
                Explore this area <ArrowUpRight size={22} />
              </span>
            </a>
          </div>
          <p className="program-footnote">
            <ShieldCheck size={15} /> Support and referrals are subject to
            available resources and capacity.
          </p>
        </div>
      </section>
      <section className="section shell why-section" id="why-it-matters">
        <figure className="why-image context-image">
          <img
            src={imagery.flags}
            alt="The Ugandan national flag alongside a Progress Pride flag against a warm sky"
            loading="lazy"
            width={1280}
            height={726}
          />
          <figcaption className="why-image-caption">
            Our focus: Uganda. Our commitment: dignity.
          </figcaption>
        </figure>
        <div className="why-copy">
          <Eyebrow>WHY IT MATTERS</Eyebrow>
          <h2>Displacement does not end the need for protection.</h2>
          <p>
            After displacement, many LGBTQ+ refugees and asylum seekers continue
            to face rejection, violence, isolation, and barriers to healthcare
            and basic needs. A safer place to live is only one part of
            rebuilding a life.
          </p>
          <p>
            Our intended impact is to strengthen protection, increase access to
            services, expand livelihood opportunities, and help people build
            more independent lives.
          </p>
          <ul className="check-list">
            <li>
              <Check size={17} /> Stronger support networks and less isolation
            </li>
            <li>
              <Check size={17} /> Greater awareness of rights and available
              services
            </li>
            <li>
              <Check size={17} /> More pathways to resilience and independence
            </li>
          </ul>
          <TextLink href="/about#our-approach">
            How our organization works
          </TextLink>
          <p className="impact-note">
            These are outcomes we work toward, not claims of measured results.
          </p>
        </div>
      </section>
      <ConferenceFeature />
      <section className="mission-band">
        <div className="shell mission-inner">
          <div>
            <Eyebrow light>OUR MISSION</Eyebrow>
            <p>{organization.mission}</p>
          </div>
          <div>
            <Eyebrow light>OUR VISION</Eyebrow>
            <p>{organization.vision}</p>
          </div>
        </div>
      </section>
      <section className="section shell commitment-section">
        <Eyebrow>OUR COMMITMENTS</Eyebrow>
        <h2>Safety, participation, and accountability.</h2>
        <div className="commitment-row">
          <div>
            <ShieldCheck size={29} />
            <h3>Protection before publicity</h3>
            <p>
              We do not publish private shelter locations or sensitive case
              details. Photos are shared only with consent and a safety review.
            </p>
          </div>
          <div>
            <Users size={29} />
            <h3>Listening to the people we support</h3>
            <p>
              Participation and feedback help our organization understand needs
              and develop appropriate support.
            </p>
          </div>
          <div>
            <Heart size={29} />
            <h3>Responsible use of resources</h3>
            <p>
              We aim to manage resources responsibly, communicate honestly, and
              strengthen our organizational capacity.
            </p>
          </div>
        </div>
      </section>
      <PartnerBanner />
      <section className="support-callout shell">
        <div>
          <span className="icon-tile lavender">
            <Heart size={23} />
          </span>
          <div>
            <h3>Looking for information or support?</h3>
            <p>Make a careful initial inquiry. Share only what feels safe.</p>
          </div>
        </div>
        <TextLink href="/get-support">Help and support</TextLink>
      </section>
    </>
  );
}
