import {
  Mail,
  Phone,
  MapPin,
  Heart,
  Handshake,
  GraduationCap,
  ArrowUpRight,
  Check,
} from "lucide-react";
import { organization } from "../../content";
import { activityPhotos } from "../../photos";
import ActivityPhoto from "../../components/harbor/ActivityPhoto";
import ContactForm from "../../components/harbor/ContactForm";
import {
  ButtonLink,
  DonationLink,
  Eyebrow,
  PageIntro,
  SafetyNote,
  TextLink,
} from "../../components/harbor/Layout";

export function Partner() {
  return (
    <>
      <PageIntro
        eyebrow="PARTNER & SUPPORT"
        title="Partner with Harbor of Hope"
        text="Support our refugee-led organization in strengthening protection, practical support, and opportunities for LGBTQ+ refugees in Uganda."
        photo={activityPhotos.exchange}
      />
      <section className="section shell partner-intro">
        <div>
          <Eyebrow>WAYS TO GET INVOLVED</Eyebrow>
          <h2>How you can support our work</h2>
        </div>
        <div>
          <p>
            We welcome engagement with donors, foundations, embassies,
            humanitarian organizations, refugee-led groups, healthcare
            providers, human rights organizations, volunteers, and technical
            partners.
          </p>
          <p>
            Our partnerships should be grounded in mutual respect,
            confidentiality, transparency, safeguarding, and a shared commitment
            to dignity and rights.
          </p>
        </div>
      </section>
      <section className="shell partnership-moments">
        <div className="section-heading">
          <div>
            <Eyebrow>CONNECTION & EXCHANGE</Eyebrow>
            <h2>Discussion and exchange</h2>
          </div>
          <p className="heading-description">
            Gathering, listening, and sharing perspectives are part of building
            our organization's support and referral work.
          </p>
        </div>
        <div className="photo-pair">
          <ActivityPhoto photo={activityPhotos.connections} />
          <ActivityPhoto photo={activityPhotos.exchange} />
        </div>
      </section>
      <section className="shell involvement-cards" id="support">
        <article className="involvement-card lavender">
          <Heart size={30} />
          <h2>Support our work</h2>
          <p>
            Help us seek resources for safe shelter, emergency protection, food,
            hygiene supplies, and essential needs.
          </p>
          <p className="field-help">
            Donations are completed on Spotfund, an external fundraising
            platform. The donation link opens in a new tab. This website does
            not collect payment details.
          </p>
          <DonationLink />
          <TextLink href="/contact?topic=Support%20our%20work">
            Discuss in-kind or other support
          </TextLink>
        </article>
        <article className="involvement-card green">
          <Handshake size={30} />
          <h2>Become a partner</h2>
          <p>
            Collaborate on healthcare, psychosocial services, legal and human
            rights referrals, skills, and community support.
          </p>
          <p className="field-help">
            Tell us about your organization and the areas where we could work
            together.
          </p>
          <ButtonLink href="/contact?topic=Partnership">
            Explore a partnership
          </ButtonLink>
        </article>
        <article className="involvement-card peach">
          <GraduationCap size={30} />
          <h2>Share your skills</h2>
          <p>
            Contribute relevant expertise in training, organizational systems,
            digital skills, monitoring, and accountability.
          </p>
          <p className="field-help">
            Volunteer and technical opportunities depend on identified needs and
            capacity.
          </p>
          <ButtonLink href="/contact?topic=Volunteering">
            Offer your expertise
          </ButtonLink>
        </article>
      </section>
      <section className="section shell priorities">
        <div>
          <Eyebrow>PRIORITY AREAS</Eyebrow>
          <h2>Our current priorities</h2>
          <TextLink href="/programs">Understand our programs</TextLink>
        </div>
        <ul className="objective-list">
          {[
            "Safe shelter and emergency protection",
            "Food, hygiene supplies, and essential needs",
            "Healthcare and psychosocial referrals",
            "Legal and human rights referrals",
            "Livelihood and skills development",
            "Organizational capacity building",
            "Staff and volunteer training",
            "Program monitoring and accountability",
          ].map(text => (
            <li key={text}>
              <Check size={18} />
              {text}
            </li>
          ))}
        </ul>
      </section>
      <section className="partnership-promise">
        <div className="shell section">
          <Eyebrow>PARTNERSHIPS BUILT ON TRUST</Eyebrow>
          <h2>Working responsibly with partners</h2>
          <div className="promise-columns">
            <p>
              We aim to manage resources responsibly and transparently, maintain
              appropriate records, and follow applicable law, organizational
              controls, and donor requirements.
            </p>
            <p>
              Our systems and program capacity continue to develop. We welcome
              honest conversations about intended outcomes, capacity,
              safeguarding, and the practical arrangements for each partnership.
            </p>
          </div>
          <div className="actions">
            <ButtonLink href="/contact?topic=Partnership">
              Start a partnership conversation
            </ButtonLink>
          </div>
        </div>
      </section>
      <section className="section shell">
        <SafetyNote>
          Partnerships must protect the safety and dignity of the community. We
          do not make beneficiary identification, private case stories, or
          shelter locations a condition of public visibility or support.
        </SafetyNote>
      </section>
    </>
  );
}

export function Contact() {
  return (
    <>
      <PageIntro
        eyebrow="CONTACT"
        title="Contact Harbor of Hope"
        text="Ask a question, explore a partnership, or make a careful initial inquiry. Please choose a channel that is safe for you."
        photo={activityPhotos.connections}
      />
      <section className="section shell contact-layout">
        <div className="contact-information">
          <Eyebrow>LET'S CONNECT</Eyebrow>
          <h2>Choose a safe contact channel</h2>
          <ContactDetails />
        </div>
        <ContactForm />
      </section>
    </>
  );
}

function ContactDetails() {
  return (
    <div className="contact-details">
      <a href={`mailto:${organization.email}`}>
        <span className="contact-icon">
          <Mail size={23} />
        </span>
        <div>
          <small>EMAIL</small>
          <strong>{organization.email}</strong>
        </div>
        <ArrowUpRight size={18} />
      </a>
      <a href={organization.phoneLink}>
        <span className="contact-icon">
          <Phone size={23} />
        </span>
        <div>
          <small>TELEPHONE</small>
          <strong>{organization.phone}</strong>
        </div>
        <ArrowUpRight size={18} />
      </a>
      <div className="postal-contact">
        <span className="contact-icon">
          <MapPin size={23} />
        </span>
        <div>
          <small>POSTAL ADDRESS</small>
          <strong>{organization.address}</strong>
        </div>
      </div>
    </div>
  );
}

export function GetSupport() {
  return (
    <>
      <PageIntro
        eyebrow="HELP & SUPPORT"
        title="Help and support"
        text="If you are looking for support or information, you can make a careful initial inquiry. Share only what is necessary, using a channel that feels safe for you."
        photo={activityPhotos.solidarity}
      />
      <section className="section shell">
        <ButtonLink href="/contact?topic=Support%20request">
          Contact us
        </ButtonLink>
      </section>
    </>
  );
}

export function Privacy() {
  return (
    <>
      <PageIntro
        eyebrow="PRIVACY & SAFEGUARDING"
        title="Privacy and safeguarding"
        text="The safety and dignity of LGBTQ+ refugees guide our public communications and our approach to initial contact."
        photo={activityPhotos.community}
      />
      <section className="section shell privacy-layout">
        <aside>
          <Eyebrow>OUR COMMITMENT</Eyebrow>
          <p>
            Careful communication is part of community protection. We encourage
            you to share less, choose safe channels, and stay in control of your
            initial inquiry.
          </p>
          <TextLink href="/contact">Ask a privacy question</TextLink>
        </aside>
        <div className="privacy-content">
          <section>
            <h2>What this website does with your inquiry</h2>
            <p>
              The Contact Us form sends your information to FormSubmit, an
              external form-to-email service, to deliver it to
              harborofhoperefugeeinitiative@gmail.com. Submitting takes you to
              FormSubmit for its spam check and submission result. You do not
              need to use your own email app. The receiving email address must
              first be activated by Harbor of Hope through FormSubmit's
              confirmation email.
            </p>
            <p>
              FormSubmit processes submissions and retains a submission archive
              for 30 days, as described in its documentation. Messages delivered
              to the organization are also handled and retained in its email
              service. Read the{" "}
              <a
                href="https://formsubmit.co/privacy.pdf"
                target="_blank"
                rel="noopener noreferrer"
              >
                FormSubmit privacy policy
              </a>{" "}
              and
              <a
                href="https://formsubmit.co/documentation"
                target="_blank"
                rel="noopener noreferrer"
              >
                documentation
              </a>{" "}
              for its practices.
            </p>
            <p>
              The Get Support page provides information and a link to Contact
              Us; it does not have a separate inquiry form. We do not save form
              contents in a website database or browser storage, and have not
              added advertising trackers, visitor analytics, or session-replay
              tools to this website.
            </p>
            <p>
              If you send an email, the message is handled by your email
              provider and received by the organization through email. Website
              hosting and communication providers may process technical
              information according to their own practices. No online channel
              can guarantee complete confidentiality.
            </p>
          </section>
          <section>
            <h2>Donations through Spotfund</h2>
            <p>
              Donation buttons open the Spotfund campaign supplied by Harbor of
              Hope in a new tab. Donations and payment details are handled on
              Spotfund under its own terms and privacy practices. This website
              does not collect payment details or process the donation.
            </p>
          </section>
          <section>
            <h2>What to share — and what not to share</h2>
            <p>
              The Contact Us form asks for first and last name and email, with
              an optional subject and message. You may use an alias.
            </p>
            <p>
              Please do not send identification documents, health records, exact
              shelter or home locations, information about other people, or
              detailed case histories through the initial form. We do not
              request attachments.
            </p>
          </section>
          <section>
            <h2>How an inquiry is used</h2>
            <p>
              If you choose to send your message, Harbor of Hope can use the
              information to consider your inquiry and communicate with you
              through your safe reply email. Sensitive information should be
              handled carefully and respectfully. Any later information-sharing
              or referral should be discussed through an appropriate follow-up
              process.
            </p>
            <p>
              You may contact the organization to ask about handling your
              information or to request a correction or removal of information
              you have shared. This website does not state a formal retention
              schedule or guarantee a response deadline.
            </p>
          </section>
          <section>
            <h2>Safe public communication</h2>
            <p>
              Private shelter addresses and sensitive case details are not
              published. Photographs or identifying information that could
              expose people to harm require informed consent and a careful
              safety assessment.
            </p>
            <p>
              Activity photographs were supplied by Harbor of Hope. The
              organization confirmed permission to use them, participant consent
              for this website, and safety clearance. Captions do not disclose
              names, private locations, or sensitive individual circumstances.
              Embedded image metadata is omitted from the website copies.
            </p>
            <p>
              The Uganda and Progress Pride flags image was supplied for this
              website. It represents the geographic focus and commitment to
              inclusion; it is not evidence of a specific program activity.
            </p>
            <p>
              Signs and third-party logos visible in supplied photographs do
              not, by themselves, indicate a formal partnership or endorsement.
              Organizations named in the separate Partners &amp; Donors section
              have been identified by Harbor of Hope as its partners and donors.
            </p>
          </section>
          <section>
            <h2>Safeguarding and accountability</h2>
            <p>
              Harbor of Hope is committed to protecting confidential
              information, respecting human dignity, and developing suitable
              safeguarding and complaints mechanisms. If you have a concern, you
              can request a safe follow-up using the contact page. Do not
              include unnecessary identifying details in the initial message.
            </p>
            <ButtonLink
              href="/contact?topic=Safeguarding%20concern"
              kind="outline"
            >
              Raise a safeguarding concern
            </ButtonLink>
          </section>
          <section>
            <h2>Quick exit and device safety</h2>
            <p>
              The Quick exit link takes you to Google in the same tab. It does
              not clear browsing history, downloaded files, email drafts,
              clipboard contents, or messages. It cannot protect you from device
              monitoring. Consider your own circumstances when choosing a
              browser, device, or communication channel.
            </p>
          </section>
          <section>
            <h2>Contact for privacy questions</h2>
            <p>
              <a href={`mailto:${organization.email}`}>{organization.email}</a>
              <br />
              {organization.phone}
              <br />
              {organization.address}
            </p>
            <p className="field-help">
              This guidance describes the website's current behavior and our
              organization's stated commitments. Last updated October 2026.
            </p>
          </section>
        </div>
      </section>
    </>
  );
}
