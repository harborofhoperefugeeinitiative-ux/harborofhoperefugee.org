import {
  ShieldCheck,
  Users,
  Scale,
  HandHeart,
  Network,
  Check,
} from "lucide-react";
import { organization, values } from "../../content";
import { branding } from "../../branding";
import { activityPhotos } from "../../photos";
import ActivityPhoto from "../../components/harbor/ActivityPhoto";
import OurStory from "../../components/harbor/OurStory";
import ConferenceFeature from "../../components/harbor/ConferenceFeature";
import { ourStory } from "../../story";
import {
  ButtonLink,
  Eyebrow,
  PageIntro,
  PartnerBanner,
} from "../../components/harbor/Layout";

export default function About() {
  const approaches = [
    [
      Users,
      "Refugee-led organization",
      "Our organization is led by refugees. Our leadership coordinates priorities and programs, informed by identified needs and feedback from the people we support.",
    ],
    [
      Scale,
      "Rights-based",
      "We promote dignity, equality, human rights awareness, and access to rights and services.",
    ],
    [
      ShieldCheck,
      "Protection-focused",
      "We seek to reduce exposure to violence, harassment, discrimination, and other forms of harm.",
    ],
    [
      HandHeart,
      "Practical & empowering",
      "Referrals, skills development, livelihood opportunities, and community support respond to real needs.",
    ],
    [
      Network,
      "Partnership-driven",
      "We seek collaboration with civil society, humanitarian, health, human rights, and development partners.",
    ],
  ];
  return (
    <>
      <PageIntro
        eyebrow="ABOUT OUR ORGANIZATION"
        title="About Us"
        text="We are a refugee-led organization in Uganda, working toward a future where every LGBTQ+ refugee and asylum seeker can live with safety, dignity, and possibility."
        photo={activityPhotos.welcome}
      />
      <section
        className="section shell story-section supplied-story-intro"
        id="our-story"
        aria-labelledby="our-story-title"
      >
        <div>
          <Eyebrow>{ourStory.title.toUpperCase()}</Eyebrow>
          <h2 id="our-story-title">{ourStory.subtitle}</h2>
          {ourStory.introduction.map(paragraph => (
            <p key={paragraph}>{paragraph}</p>
          ))}
          <p className="story-scope-note">
            Our current programs and operations focus on LGBTQ+ refugees in
            Uganda. Our wider registered objectives also cover refugees, asylum
            seekers, and other LGBTQ+ community members.
          </p>
        </div>
        <aside className="at-a-glance">
          <img
            className="official-full-logo"
            src={branding.fullLogo}
            alt="Official Harbor of Hope Refugee Support Initiative logo: protective hands, an Africa silhouette, hearts, people, and rainbow colors"
            width={720}
            height={833}
            loading="lazy"
          />
          <Eyebrow>HARBOR AT A GLANCE</Eyebrow>
          <dl>
            <div>
              <dt>Founded</dt>
              <dd>{ourStory.founded}</dd>
            </div>
            <div>
              <dt>Leadership</dt>
              <dd>Refugee-led organization</dd>
            </div>
            <div>
              <dt>Current geographic focus</dt>
              <dd>Uganda</dd>
            </div>
            <div>
              <dt>Current program focus</dt>
              <dd>LGBTQ+ refugees</dd>
            </div>
            <div>
              <dt>Postal address</dt>
              <dd>{organization.address}</dd>
            </div>
          </dl>
          <ButtonLink href="/contact" kind="outline">
            Contact our team
          </ButtonLink>
        </aside>
      </section>
      <OurStory />
      <section className="shell community-moments">
        <div className="section-heading">
          <div>
            <Eyebrow>FROM OUR COMMUNITY</Eyebrow>
          </div>
        </div>
        <div className="photo-pair">
          <ActivityPhoto photo={activityPhotos.community} />
          <ActivityPhoto photo={activityPhotos.pride} />
        </div>
      </section>
      <ConferenceFeature />
      <section className="shell mission-cards">
        <div className="mission-card lavender">
          <Eyebrow>OUR MISSION</Eyebrow>
          <h2>Protection, support, and empowerment</h2>
          <p>{organization.mission}</p>
        </div>
        <div className="mission-card green">
          <Eyebrow>OUR VISION</Eyebrow>
          <h2>Safety and dignity without fear</h2>
          <p>{organization.vision}</p>
        </div>
      </section>
      <section className="section shell" id="our-approach">
        <div className="section-heading">
          <div>
            <Eyebrow>OUR APPROACH</Eyebrow>
            <h2>How our organization works</h2>
          </div>
          <p className="heading-description">
            Human dignity is the starting point for every program, referral, and
            partnership.
          </p>
        </div>
        <div className="approach-list">
          {approaches.map(([Icon, title, text]) => {
            const I = Icon as typeof Users;
            return (
              <div key={String(title)}>
                <I size={26} />
                <h3>{String(title)}</h3>
                <p>{String(text)}</p>
              </div>
            );
          })}
        </div>
      </section>
      <section className="values-section">
        <div className="shell section">
          <Eyebrow>WHAT WE STAND FOR</Eyebrow>
          <h2>Values that guide our work</h2>
          <div className="values-list">
            {values.map(([title, text]) => (
              <div key={title}>
                <h3>{title}</h3>
                <p>{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      <section className="section shell objectives">
        <div>
          <Eyebrow>OUR OBJECTIVES</Eyebrow>
          <h2>Our objectives</h2>
          <div className="objectives-note">
            <strong>Care. Protect. Empower.</strong>
            <p>
              Our objectives connect protection, access to essential services,
              rights awareness, skills, and responsible partnerships.
            </p>
          </div>
        </div>
        <ul className="objective-list">
          {[
            "Improve access to healthcare and appropriate service referrals.",
            "Reduce violence, harassment, and discrimination through awareness, protection, and community support.",
            "Promote human rights awareness and help LGBTQ+ refugees and asylum seekers understand and seek to exercise their rights.",
            "Promote economic empowerment through skills, vocational learning, and income-generating opportunities.",
            "Strengthen community support systems and participation.",
            "Build partnerships and organizational capacity to improve program delivery.",
            "Undertake other lawful activities that support our registered objectives.",
          ].map(text => (
            <li key={text}>
              <Check size={19} />
              <span>{text}</span>
            </li>
          ))}
        </ul>
      </section>
      <PartnerBanner />
      <div className="section-spacer" />
    </>
  );
}
