import { ArrowUpRight, Check, Plus } from "lucide-react";
import { programs } from "../../content";
import { activityPhotos, type ActivityPhotoData } from "../../photos";
import ActivityPhoto from "../../components/harbor/ActivityPhoto";
import {
  PageIntro,
  PartnerBanner,
  SafetyNote,
} from "../../components/harbor/Layout";

const programPhotos: Record<string, ActivityPhotoData> = {
  "safe-shelter": activityPhotos.solidarity,
  "human-rights": activityPhotos.advocacy,
  "community-outreach": activityPhotos.outreach,
};

export default function Programs() {
  return (
    <>
      <PageIntro
        eyebrow="OUR WORK"
        title="Programs & Services"
        text="The areas of work that support our mission are to protect, support, and empower LGBTQ+ refugees in Uganda. Every program begins with dignity."
        photo={activityPhotos.outreach}
      />
      <section className="section shell">
        <SafetyNote>
          Our programs describe the support we seek to coordinate and develop.
          Specific assistance, referrals, and activities depend on available
          resources, service providers, and organizational capacity.
        </SafetyNote>
        <nav className="program-jump" aria-label="Explore program areas">
          {programs.map(program => (
            <a key={program.id} href={`#${program.id}`}>
              {program.title}
            </a>
          ))}
        </nav>
        <div className="all-programs">
          {programs.map((program, index) => (
            <article
              className="program-detail"
              id={program.id}
              key={program.id}
            >
              <div className={`program-icon-panel ${program.color}`}>
                <program.icon size={58} strokeWidth={1.3} />
                <span>{program.category}</span>
              </div>
              <div className="program-detail-copy">
                <div className="program-detail-kicker">{program.category}</div>
                <h2>{program.title}</h2>
                <p>{program.summary}</p>
                {programPhotos[program.id] && (
                  <ActivityPhoto photo={programPhotos[program.id]} />
                )}
                <details open={index === 0}>
                  <summary>
                    Our focus and possible activities <Plus size={19} />
                  </summary>
                  <div>
                    <p>{program.details}</p>
                    <ul className="check-list">
                      {program.activities.map(activity => (
                        <li key={activity}>
                          <Check size={16} />
                          {activity}
                        </li>
                      ))}
                    </ul>
                  </div>
                </details>
                <a
                  className="text-link"
                  href={`/contact?topic=${encodeURIComponent("Partnership")}&program=${encodeURIComponent(program.id)}`}
                >
                  Explore a partnership in this area <ArrowUpRight size={18} />
                </a>
              </div>
            </article>
          ))}
        </div>
      </section>
      <PartnerBanner />
      <div className="section-spacer" />
    </>
  );
}
