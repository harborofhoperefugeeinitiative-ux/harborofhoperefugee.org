import {
  House,
  HeartPulse,
  HandHeart,
  Scale,
  ShoppingBasket,
  Sprout,
  Users,
  Network,
} from "lucide-react";

export const organization = {
  name: "Harbor of Hope Refugee Support Initiative",
  tagline: "Care. Protect. Empower. Together, We Bring Hope.",
  email: "harborofhoperefugeeinitiative@gmail.com",
  phone: "+256 790 448 018",
  phoneLink: "tel:+256790448018",
  donationUrl: "http://spot.fund/d8qhqnrsc",
  address: "P. O. Box 209824, Kampala, Uganda",
  mission:
    "to protect, support, and empower LGBTQ+ refugees and asylum seekers through community-based protection, access to essential services, human rights awareness, psychosocial support, livelihood opportunities, and strategic partnerships.",
  vision:
    "An inclusive, safe, and dignified society where LGBTQ+ refugees and asylum seekers can live without fear.",
};

export const imagery = {
  flags: "/manus-storage/uganda-pride-flags_cd0ea0f1.webp",
};

export const programs = [
  {
    id: "safe-shelter",
    title: "Safe shelter & emergency protection",
    shortTitle: "A safer place to begin",
    icon: House,
    category: "PROTECT",
    color: "lavender",
    summary:
      "Coordinating support for people facing homelessness, threats, violence, or unsafe living conditions.",
    details:
      "We seek and coordinate support for LGBTQ+ refugees and asylum seekers. Depending on available resources, this may include emergency accommodation support, safety planning, essential items, and referrals. Private shelter locations are never shared publicly.",
    activities: [
      "Emergency accommodation coordination",
      "Safety planning and protection referrals",
      "Essential items, where resources allow",
    ],
  },
  {
    id: "health-access",
    title: "Health access & medical referrals",
    shortTitle: "Care without barriers",
    icon: HeartPulse,
    category: "CARE",
    color: "green",
    summary:
      "Connecting community members with appropriate healthcare providers and respectful services.",
    details:
      "We help community members connect with appropriate healthcare providers, including HIV-related care, sexual health information, and STI prevention. Our role is to facilitate information and referrals, not to replace clinical care.",
    activities: [
      "Appropriate healthcare referrals",
      "HIV-related care connections",
      "Sexual health and STI prevention information",
    ],
  },
  {
    id: "mental-health",
    title: "Mental health & psychosocial support",
    shortTitle: "No one should feel alone",
    icon: HandHeart,
    category: "CARE",
    color: "peach",
    summary:
      "Supporting emotional well-being through counseling referrals, psychosocial services, and peer support.",
    details:
      "Displacement and exclusion can affect emotional well-being. We promote supportive connections and help people access suitable counseling, psychosocial services, and peer support where available.",
    activities: [
      "Counseling and psychosocial referrals",
      "Peer support, where available",
      "Community connections that reduce isolation",
    ],
  },
  {
    id: "human-rights",
    title: "Human rights advocacy & legal referrals",
    shortTitle: "Dignity and rights",
    icon: Scale,
    category: "PROTECT",
    color: "lavender",
    summary:
      "Sharing rights information and connecting people with relevant legal aid and human rights organizations.",
    details:
      "We promote human rights awareness, responsibly document protection concerns, and connect community members with relevant legal aid and human rights organizations. We handle sensitive information carefully and do not publish individual cases.",
    activities: [
      "Human rights awareness",
      "Responsible protection documentation",
      "Legal aid and human rights referrals",
    ],
  },
  {
    id: "essential-needs",
    title: "Food & essential needs",
    shortTitle: "Support for everyday needs",
    icon: ShoppingBasket,
    category: "CARE",
    color: "peach",
    summary:
      "Seeking resources for food, hygiene products, and basic needs for people facing urgent hardship.",
    details:
      "We seek resources to help address urgent hardship through food, hygiene products, and other basic needs. The support we can coordinate depends on available resources and organizational capacity.",
    activities: [
      "Food assistance resource mobilization",
      "Hygiene and essential supplies",
      "Coordination around urgent basic needs",
    ],
  },
  {
    id: "livelihoods",
    title: "Livelihoods & skills development",
    shortTitle: "Skills for a stronger future",
    icon: Sprout,
    category: "EMPOWER",
    color: "green",
    summary:
      "Promoting digital skills, vocational learning, and opportunities for more independent lives.",
    details:
      "We promote digital skills, vocational learning, livelihood development, and economic empowerment opportunities. We aim to help community members strengthen their skills and pursue greater independence.",
    activities: [
      "Digital skills development",
      "Vocational learning opportunities",
      "Livelihood and income-generating pathways",
    ],
  },
  {
    id: "community-outreach",
    title: "Community outreach & empowerment",
    shortTitle: "Stronger, together",
    icon: Users,
    category: "EMPOWER",
    color: "green",
    summary:
      "Strengthening peer education, inclusion, community participation, and support networks.",
    details:
      "Our refugee-led organization encourages participation and feedback from the people it supports. We promote peer education, health awareness, inclusion, and stronger support networks so that people can participate in decisions that affect their lives.",
    activities: [
      "Peer education and health awareness",
      "Community participation",
      "Inclusive support networks",
    ],
  },
  {
    id: "partnerships",
    title: "Partnership & organizational development",
    shortTitle: "Building the capacity to care",
    icon: Network,
    category: "EMPOWER",
    color: "lavender",
    summary:
      "Building meaningful partnerships and strengthening governance and program systems.",
    details:
      "We build relationships with civil society, humanitarian, health, human rights, and development partners. We also seek to strengthen governance, program systems, staff and volunteer training, monitoring, and accountability.",
    activities: [
      "Cross-sector partnerships",
      "Governance and program capacity",
      "Training, monitoring, and accountability",
    ],
  },
];

export const values = [
  ["Dignity", "Every person deserves respect and humane treatment."],
  [
    "Safety",
    "We prioritize the protection and well-being of the people we serve.",
  ],
  [
    "Equality & inclusion",
    "Fair access to services and opportunities, without discrimination.",
  ],
  [
    "Solidarity",
    "We work alongside community members and partners on shared challenges.",
  ],
  [
    "Confidentiality",
    "Personal and sensitive information is handled carefully and respectfully.",
  ],
  [
    "Accountability",
    "Responsible use of resources and honest communication about our work.",
  ],
  [
    "Empowerment",
    "People participate in decisions and build skills and independence.",
  ],
];

export const routes = [
  {
    path: "/",
    title: "Harbor of Hope | LGBTQ+ Refugee Support in Uganda",
    description:
      "A refugee-led organization supporting, protecting, and empowering LGBTQ+ refugees and asylum seekers in Uganda. Care. Protect. Empower. Together, We Bring Hope.",
  },
  {
    path: "/about",
    title: "About Us | Harbor of Hope Refugee Support Initiative",
    description:
      "Founded in 2024, Harbor of Hope is a refugee-led organization in Uganda. Read our story and learn about our mission, vision, values, and approach.",
  },
  {
    path: "/programs",
    title: "Our Programs | Harbor of Hope Refugee Support",
    description:
      "Explore Harbor of Hope's eight program areas: protection, shelter, health referrals, psychosocial support, rights, essential needs, livelihoods, and organizational development.",
  },
  {
    path: "/partner",
    title: "Partner & Support | Harbor of Hope Refugee Initiative",
    description:
      "Partner with Harbor of Hope, a refugee-led organization strengthening protection and opportunities for LGBTQ+ refugees in Uganda with dignity and transparency.",
  },
  {
    path: "/get-support",
    title: "Help & Support | Harbor of Hope Refugee Initiative",
    description:
      "Learn how to make a careful initial support inquiry. Assistance and referrals depend on resources and capacity. Your privacy and safety matter.",
  },
  {
    path: "/contact",
    title: "Contact Us | Harbor of Hope Refugee Support Initiative",
    description:
      "Contact Harbor of Hope in Uganda by email or telephone. Make a privacy-conscious inquiry about support, partnerships, or volunteering.",
  },
  {
    path: "/privacy",
    title: "Privacy & Safeguarding | Harbor of Hope Initiative",
    description:
      "How Harbor of Hope's website approaches privacy, safe initial inquiries, confidentiality, safeguarding, and responsible public communication.",
  },
];

export function routeFor(path: string) {
  return routes.find(route => route.path === path);
}
