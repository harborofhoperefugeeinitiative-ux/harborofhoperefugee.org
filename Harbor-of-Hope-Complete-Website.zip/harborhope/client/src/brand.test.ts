import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const base = readFileSync(new URL("./index.css", import.meta.url), "utf8");
const refined = readFileSync(
  new URL("./styles/brand.css", import.meta.url),
  "utf8"
);
const hero = readFileSync(
  new URL("./styles/hero.css", import.meta.url),
  "utf8"
);
const main = readFileSync(new URL("./main.tsx", import.meta.url), "utf8");
const tokens = Object.fromEntries(
  [...base.matchAll(/--([a-z-]+):\s*(#[0-9a-f]{6});/g)].map(match => [
    match[1],
    match[2],
  ])
);
function luminance(color: string) {
  const channels = [1, 3, 5].map(
    index => parseInt(color.slice(index, index + 2), 16) / 255
  );
  const linear = channels.map(value =>
    value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4
  );
  return linear.reduce(
    (sum, value, index) => sum + value * [0.2126, 0.7152, 0.0722][index]!,
    0
  );
}
function contrast(foreground: string, background: string) {
  const values = [luminance(foreground), luminance(background)].sort(
    (a, b) => a - b
  );
  return (values[1]! + 0.05) / (values[0]! + 0.05);
}

describe("Professional logo-matched design", () => {
  it("uses navy, cyan, and magenta instead of the unrelated legacy palette", () => {
    expect(tokens.navy).toBe("#0b104b");
    expect(tokens.cyan).toBe("#23c6e4");
    expect(tokens.magenta).toBe("#b9247f");
    expect(tokens.canvas).toBe("#dce7f1");
    expect(tokens.surface).toBe("#eaf1f7");
    expect(base + refined).not.toMatch(
      /--(plum|cream|lavender|green|peach|lime)\b/
    );
    expect(main.indexOf('"./styles/brand.css"')).toBeGreaterThan(
      main.indexOf('"./index.css"')
    );
  });
  it("meets normal-text contrast for the intended light and dark surface combinations", () => {
    const pairs = [
      ["surface", "navy"],
      ["surface", "magenta"],
      ["surface", "magenta-hover"],
      ["navy", "cyan"],
      ["magenta", "canvas"],
      ["magenta-text", "tint-pink"],
      ["magenta-text", "tint-blue"],
      ["cyan-text", "surface"],
      ["cyan-text", "tint-cyan"],
      ["cyan-text", "tint-blue"],
      ["muted", "canvas"],
      ["muted", "tint-blue"],
      ["muted", "tint-cyan"],
      ["muted", "tint-pink"],
      ["on-dark", "navy"],
      ["on-dark", "navy-deep"],
    ];
    for (const [foreground, background] of pairs) {
      expect(
        contrast(tokens[foreground!]!, tokens[background!]!),
        `${foreground} on ${background}`
      ).toBeGreaterThanOrEqual(4.5);
    }
  });
  it("keeps field boundaries and keyboard focus visible on tinted surfaces", () => {
    expect(
      contrast(tokens["field-border"]!, tokens.surface!)
    ).toBeGreaterThanOrEqual(3);
    expect(
      contrast(tokens["cyan-text"]!, tokens.surface!)
    ).toBeGreaterThanOrEqual(3);
    expect(contrast(tokens.cyan!, tokens.navy!)).toBeGreaterThanOrEqual(3);
  });
  it("resolves every custom-property reference and retains full-composition photo rules", () => {
    const cascade = base + refined + hero;
    const definitions = new Set(
      [...cascade.matchAll(/--([a-z-]+):/g)].map(match => match[1])
    );
    for (const match of cascade.matchAll(/var\(--([a-z-]+)\)/g)) {
      expect(definitions.has(match[1]), `Definition for ${match[1]}`).toBe(
        true
      );
    }
    expect(base).toMatch(
      /\.activity-photo img\s*\{[^}]*height: auto;[^}]*object-fit: contain;/
    );
    expect(base).toMatch(
      /\.hero-photo\.community-hero img\s*\{[^}]*height: auto;[^}]*object-fit: contain;/
    );
    expect(refined).toContain("prefers-reduced-motion: reduce");
    expect(refined).not.toMatch(/filter\s*:/);
  });
});
