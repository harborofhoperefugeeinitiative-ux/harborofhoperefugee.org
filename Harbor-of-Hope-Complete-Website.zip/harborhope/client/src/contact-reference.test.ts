import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { render } from "./entry-server";
import { buildReferenceInquiry } from "./components/harbor/ReferenceContactFields";
import { organization } from "./content";

const css = readFileSync(
  new URL("./styles/brand.css", import.meta.url),
  "utf8"
);

describe("Reference Contact Us form", () => {
  it("renders reference labels, empty outlined fields, required name/email and optional subject/message", () => {
    const { html } = render("/contact");
    expect(html).toContain('class="inquiry-form-wrap reference-contact-form"');
    for (const text of [
      "Name",
      "First</label>",
      "Last</label>",
      "Email",
      "Subject",
      "Comment or Message",
      ">Submit</button>",
    ])
      expect(html).toContain(text);
    expect(html).not.toContain("Objectif");
    expect(html).toContain('aria-label="Subject"');
    for (const name of ["firstName", "lastName", "email"])
      expect(
        html.match(new RegExp(`<input[^>]*name="${name}"[^>]*>`))![0]
      ).toContain('required=""');
    const message = html.match(/<textarea[^>]*name="message"[^>]*>/)![0];
    expect(message).not.toContain("required");
    expect(message).toContain('maxLength="1200"');
    expect(html).not.toContain("What would you like to discuss?");
    expect(html).not.toContain('name="consent"');
    expect(html).not.toContain("Submit continues to FormSubmit");
    expect(html).not.toContain("You may use an alias");
    expect(html).not.toContain("retains a submission archive for 30 days");
    expect(html).not.toContain('aria-describedby="contact-form-note"');
    expect(html).toContain(
      `action="https://formsubmit.co/${organization.email}"`
    );
    expect(html).toContain('method="POST"');
    expect(html).toContain('name="_honey"');
    expect(html).not.toContain('name="_captcha"');
    expect(html).not.toContain('name="_cc"');
  });
  it("matches the white panel and blue action with responsive name columns", () => {
    expect(css).toMatch(
      /\.reference-contact-form\s*\{[^}]*background: #ffffff;/
    );
    expect(css).toMatch(
      /\.reference-submit\s*\{[^}]*background: #086ea3;[^}]*color: #ffffff;/
    );
    expect(css).toMatch(
      /\.reference-name-row\s*\{[^}]*repeat\(2, minmax\(0, 1fr\)\)/
    );
    expect(css).toMatch(
      /@media \(max-width: 480px\)[\s\S]*\.reference-name-row\s*\{\s*grid-template-columns: 1fr;/
    );
  });
  it("combines names and safely encodes the optional subject/message and program context", () => {
    const data = new FormData();
    data.set("firstName", "  Alex  ");
    data.set("lastName", "  Sam & Co ");
    data.set("reply", "safe@example.org");
    data.set("topic", "Training & skills");
    data.set("message", "A question?\nPlease contact us.");
    const result = buildReferenceInquiry(
      data,
      "Livelihoods & skills development"
    );
    expect(result.mailto).toMatch(
      new RegExp(
        `^mailto:${organization.email.replace(/\./g, "\\.")}\\?subject=`
      )
    );
    const params = new URLSearchParams(result.mailto.split("?")[1]);
    expect(params.get("subject")).toBe("Harbor of Hope — Training & skills");
    expect(params.get("body")).toContain("Name / alias: Alex Sam & Co");
    expect(params.get("body")).toContain(
      "Program area: Livelihoods & skills development"
    );
    expect(params.get("body")).toContain("A question?\nPlease contact us.");
    data.set("topic", "");
    data.set("message", "");
    expect(buildReferenceInquiry(data).subject).toBe(
      "Harbor of Hope — General inquiry"
    );
  });
  it("routes Get Support to Contact Us and keeps privacy descriptions current", () => {
    const support = render("/get-support").html;
    expect(support).not.toContain("reference-contact-form");
    expect(support).not.toContain("Name or alias");
    expect(support).not.toContain('name="consent"');
    expect(support).not.toContain("Prepare email draft");
    expect(support).toContain('href="/contact?topic=Support%20request"');
    const privacy = render("/privacy").html;
    expect(privacy).toContain(
      "The Contact Us form asks for first and last name and email"
    );
    expect(privacy).toContain("You may use an alias");
    expect(privacy).not.toContain("The Get Support form");
  });
});
