export default {
  logoUrl:
    "https://files.manuscdn.com/user_upload_by_module/session_file/310519663963969183/kHgtArtjveXmQReg.png",
};
