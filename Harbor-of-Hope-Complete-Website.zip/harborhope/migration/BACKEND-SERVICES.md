# Backend and external-service migration notes

## What the current public website actually needs

The seven public website pages are a React frontend rendered into ordinary HTML, CSS, JavaScript, images, and fonts. Navigation uses normal page links. The public entrypoint does not initialize tRPC, login, a map, AI chat, or a database. The portable default server only serves files and provides `/api/health`. You can instead upload `dist/public/` to a conventional static host and run no Node server at all.

| Feature | Current implementation | What you need outside Manus |
| --- | --- | --- |
| Contact form | Native browser POST to `https://formsubmit.co/harborofhoperefugeeinitiative@gmail.com` | Continued access to this mailbox, FormSubmit recipient activation, and provider availability. Set the public `VITE_SITE_URL` before building. |
| Support inquiries | `/get-support` links to `/contact?topic=Support%20request`; no separate support form | The same Contact form or the existing public email/telephone channels. |
| Donations | Existing buttons open `http://spot.fund/d8qhqnrsc` in a new tab | Continued control of the supplied Spotfund campaign. Spotfund handles payment details, not this website. |
| Email and telephone links | Existing `mailto:` and `tel:` links | A visitor's email or calling application. No server mail transport is implemented for these links. |
| Images and fonts | Local files, including backed-up images in `client/public/manus-storage/` | Upload the complete public output; no Manus storage connection is needed for these existing files. |
| Quick exit | Existing same-tab Google link | A browser with internet access; it does not clear history or provide protection from device monitoring. |

The exported form has the same fields, native POST behavior, spam-honeypot field, and query-string subject/program preselection as the original. No real message was submitted during this export, and mailbox activation or inbox delivery was not independently verified. After you deploy, use a non-sensitive test message, complete any provider confirmation, and confirm actual receipt in your mailbox. Do not send real beneficiary records, identification, precise shelter locations, or health information through a test.

The original privacy wording describes FormSubmit processing and Spotfund donation handling. That text was preserved, not reverified against provider policy changes. If you later replace either provider, review the website privacy wording so it accurately describes the replacement.

## Original backend source retained for completeness

`server/`, `shared/`, `drizzle/`, `drizzle.config.ts`, and the original backend-related client components remain in this copy. They came from the original React/Express/tRPC/Drizzle template; they are not required for the existing public UI. The schema and SQL migrations describe a `users` table. There was no enabled project database or active public-site login to export, and this package contains no production user data or database dump.

| Retained code | Dependency if you choose to use it | Current public-site status |
| --- | --- | --- |
| `server/_core/oauth.ts`, `sdk.ts`, `context.ts`, client `useAuth` | Manus OAuth endpoints, project identity, signing secret, and potentially the MySQL user table | Not called by the seven public pages. Not a portable standalone login system. |
| `server/db.ts`, `drizzle/schema.ts`, SQL migrations | Your own MySQL-compatible service and private `DATABASE_URL` | Not needed for the static website. No database connection or migrations were run. |
| `server/storage.ts`, `_core/storageProxy.ts` | Manus service API configuration and managed storage | Not needed for existing backed-up images. The original storage proxy was not registered by the original server. |
| LLM, image, speech, data API, map, owner notification, and heartbeat helpers | Manus service/API settings and relevant provider capabilities | Dormant helpers; no active public feature uses them. |
| `Map`, `AIChatBox`, `DashboardLayout`, legacy `Home`, `ComponentShowcase` | Whatever services a future developer chooses to implement | Not reachable through `App.tsx`'s public routes. The showcase chat is not a real public AI service. |
| tRPC auth/system routes | Original Express backend and any required platform settings | Not used by the portable default static server. |

For the optional original backend, `pnpm build:backend` builds the public pages and `dist/index.js`; `pnpm start:backend` starts that original server in production mode. Its build and local startup can be checked without credentials, but real OAuth, database, managed storage, AI, and notification operations cannot function independently merely because the source is included. Replace these helpers with your chosen providers before exposing those APIs publicly. Do not use the dormant backend as an independently verified authentication or payment implementation.

Relevant variable names in the retained source include `DATABASE_URL`, `MANUS_PROJECT_ID`, `MANUS_JWT_SECRET`, `MANUS_OAUTH_API_URL`, `MANUS_OAUTH_PORTAL_URL`, `MANUS_API_URL`, `MANUS_API_KEY`, `MANUS_API_BROWSER_KEY`, and `OWNER_OPEN_ID`. Names are documented for code understanding only; no values are exported. Private credentials must be configured only in your own host's protected server environment, never in frontend source, `VITE_*` variables, or this downloadable archive. The current public website needs none of them.

## External assets and licensing

All 17 currently referenced managed image assets have been included as binary files. `asset-manifest.json` identifies their original website URLs and checksums. Those original URLs are provenance, not runtime dependencies. Official logos, partner logos, activity photographs, the conference photograph, flags, and the latest homepage illustration retain their existing website composition and bytes.

Five local font files and the two included SIL Open Font License texts are present under `client/public/fonts/`. Lucide icons used by the site are generated from the retained `lucide-react` package and compiled into the frontend JavaScript. Package licenses remain with their respective packages. The original project declares an MIT package license; that declaration does not transfer ownership of third-party logos or create new usage permissions for photographs. Continue respecting the organization's existing participant-consent and partner-logo permissions.
