# Export provenance and compatibility changes

This export starts from Harbor of Hope's clean saved source commit `926faa8e407d4e404ce067c5a37ac5c13a1b59fd` (22 October 2026). The last saved changes include the supplied homepage illustration and the larger homepage audience tagline. The referenced task says these latest changes were saved in Preview but not yet published. This export uses that latest saved version, not an older public deployment. No publication, Git push, or change to the original project was performed by this export task.

`original-source.zip` contains all 181 files tracked at that commit, with their exact original folder structure under `harborhope-original/`. It is an unmodified source snapshot, not a fully self-contained deployment: managed images were outside Git and have been backed up in the main portable project. Git history and Git transport credentials are not included. The original README is retained inside that snapshot.

## Main portable project changes

- All 17 existing managed image files have been downloaded and stored under `client/public/manus-storage/`. Their original relative URLs and filenames are unchanged. On independent hosting, `manus-storage` is now just a normal local directory; it does not contact a Manus API. See `asset-manifest.json` for original sources, byte lengths, and SHA-256 checksums.
- All original page components, content records, stylesheets, local fonts, font licenses, and navigation link values remain intact. The only active component adjustment is the Contact form's domain fallback: it now uses the public `VITE_SITE_URL` setting instead of the old Manus hostname. No visible form fields or text were changed.
- `branding.ts` uses the locally backed-up official logo for social-image metadata. `siteConfig.ts` supplies the deployment origin and validates that it contains no credentials, path, query, or fragment.
- The HTML entry no longer loads the unused `/api/platform/config.js` script. Vite no longer emits that public platform configuration, and the unused builder JSX-location plugin/dependency has been removed. The lockfile was refreshed for this removal; other application dependency declarations were retained.
- Vite uses its safe localhost/IP development-host defaults rather than a Manus-specific allowed-host list. For an intentionally exposed development domain, add only that explicit hostname; do not use `allowedHosts: true` on an untrusted network.
- `scripts/prerender.ts` loads `.env` so the Node page-rendering step uses the same public origin as Vite. It excludes the unused `__manus__/debug-collector.js` from deployable output. That file is still in the complete source snapshot and source folder, but is neither referenced nor executed by the portable public website.
- Default `dev`, `build`, and `start` commands now run the portable website. `build` prerenders every public page; `start` runs the new dependency-free Node static server. The original server, tRPC, authentication, storage, AI, and database source remains present. `build:backend` and `start:backend` provide explicit optional access to that original template backend.
- The Dockerfile now builds and runs the independent static server. The public domain is supplied with a `VITE_SITE_URL` build argument. No private environment file is copied into the container.
- A public `.env.example`, independent-hosting README, service notes, asset manifest, verification results, and this change record have been added.

No colors, fonts, layout rules, responsive breakpoints, animations, organization wording, program wording, donation link, partner names, activity captions, or public contact details were redesigned or intentionally changed.

## Files intentionally not exported as live credentials/runtime material

No real `.env` files, passwords, private keys, cookies, session data, Git credential settings, platform runtime secrets, `node_modules`, or local caches are included. Dependencies are reproducible through the pinned pnpm version and lockfile. These exclusions are not missing application source. The project does not use an active website database; no database data was available or required for the public site. Dormant schema/migration files are retained.
