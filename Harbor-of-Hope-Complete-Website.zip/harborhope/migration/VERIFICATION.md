# Export verification and publishing checklist

Verification date: **22 October 2026**. Source version: `926faa8e407d4e404ce067c5a37ac5c13a1b59fd`. Tests ran in a separate export directory, not by altering or publishing the original site. The original project remained clean at the same commit.

## Included

| Item | Result |
| --- | --- |
| Complete original source snapshot | All **181** original tracked files are present in `original-source.zip`. All 181 corresponding paths remain in the main portable project as well. |
| Portable source, configuration, and production files | Included. Ten original files have documented export-only changes; 171 original files are unchanged. |
| Every public page | All seven routes and the custom 404 page are included. |
| Website text, organization details, programs, and design | Original `App.tsx`, content records, all four public page modules, and all three original stylesheets are byte-identical to the snapshot. Other active layout/feature components are unchanged except the Contact form's hosting-domain fallback and social-image URL configuration. |
| Website images | All **17** referenced managed image assets have local copies with matching SHA-256 checksums. Their original paths and filenames are preserved. |
| Original external social-preview image | Downloaded and confirmed byte-identical to the backed-up official mark; no additional remote artwork is required. |
| Local fonts, font licenses, favicons, and icons | Included. Lucide icons are compiled from the original retained dependency. |
| Backend and database source | Original source helpers, schema, and SQL migrations included; these are not active requirements of the public website. No enabled website database or production database records were available to export. |
| README and service migration notes | Included, with independent static/Node hosting instructions, optional Docker instructions, and `.env.example`. |
| Private credentials | No real private environment files, runtime secrets, browser sessions, Git credentials, or `node_modules` were exported. Pattern scans found no credential-like findings in checked-in source or the final source/bundle text. Pattern scanning is a safeguard, not a formal security audit. |

## Tested successfully

| Check | Evidence/result |
| --- | --- |
| Dependency installation | Pinned **pnpm 10.18.0**, frozen lockfile installation succeeded; required dependency build scripts were allowed, with none reported ignored. |
| TypeScript | `pnpm check` passed. |
| Existing automated tests | `pnpm test` passed: **74 tests across 18 files**. Platform service tests use mocks/test-only values and do not prove live integration availability. |
| Portable production build | `pnpm build` passed without Manus credentials, producing all seven prerendered pages, bundled CSS/JavaScript, 404 output, and local assets. |
| Optional original-backend build | `pnpm build:backend` passed without platform credentials and produced `dist/index.js`. This establishes compilation, not live OAuth/AI/storage functionality. |
| Production server | Portable Node server started and `/api/health` returned HTTP 200 with `{"status":"ok"}`. |
| Page HTTP responses | All seven public routes and their non-root trailing-slash forms returned the expected HTML with no unfilled prerender placeholders. |
| Internal links and anchors | **180** internal link occurrences checked, including query-string links and fragment targets. No missing internal route/anchor was found. |
| Asset HTTP responses | **26** unique referenced local asset paths checked; responses matched local file bytes and did not return fallback HTML. |
| Backed-up image content | All 17 image responses matched their asset-manifest checksums and image MIME types. |
| Desktop/mobile browser | Chromium checked every route at **1366×900** and **390×844**: 14 page/viewport checks. Images loaded, headers/footers rendered, and no horizontal overflow was detected at these sizes. Lazy images were made eager only in the test browser so all below-the-fold files could be checked. |
| JavaScript runtime | No uncaught JavaScript errors were observed in these browser checks. |
| Mobile navigation | Menu open/close state, Escape dismissal, and navigation to Contact passed. |
| Contact form behavior | Required-field invalid/valid checks and subject/program query-string preselection passed. JavaScript used the actual current origin for `_url`. The native form action remained FormSubmit. No Submit click or real email was sent. |
| Without JavaScript | Contact page content and native form rendering verified; default local build `_url` is `http://localhost:3000/contact`. Configure the production origin before deployment. |
| Independent origin setting | A non-Manus example origin successfully reached the Node-rendered contact source URL and local absolute social-image metadata. |
| Unknown pages/missing assets | Unknown page, missing image, missing JS file, and unused `/api/platform/config.js` returned real 404s. Hidden `.env` access was denied by the portable server. |
| Builder runtime removal | Portable HTML does not load public platform config. The production output omits builder debug-collector files. Existing images are ordinary local files, not Manus storage requests. |
| Original project preservation | Original Git working tree remained clean at the selected saved commit. No push, publication, or DNS change was performed. |

Detailed evidence is in `verification/`: build command logs/results, HTTP results, browser results, source preservation results, asset/social-image checksums, and secret-pattern scans. ZIP integrity and file completeness are also checked during packaging; `FILE-MANIFEST.json` lists exported file paths and SHA-256 hashes, excluding its own entry to avoid a recursive checksum.

## Warnings and boundaries

Dependency installation reported existing deprecations for Recharts 2.x and some transitive packages. Versions were not broadly upgraded because that could change the existing application/design. This export does not constitute an independent dependency-security audit. Automated platform-helper tests emit expected missing-OAuth/test-payload diagnostics when no real platform configuration is supplied; those tests still pass.

No real Contact submission, FormSubmit activation, mailbox receipt, donation checkout/payment, campaign ownership, DNS configuration, HTTPS provisioning, third-party-host deployment, Docker image build, MySQL migration, OAuth login, managed storage upload, AI generation, notification delivery, or other dormant platform API operation was performed. The optional original backend was compiled but its real integrations were not configured or exercised. The browser tests cover the reported routes/viewports and targeted interactions, not every device, accessibility scenario, external service, or possible future content state.

The latest saved changes were not yet published in the original task. This ZIP therefore represents the latest saved source, not necessarily the older currently public website deployment. The live site was left untouched.

## What you must do before publishing

- [ ] Set `.env` or the host's public build setting `VITE_SITE_URL` to your actual HTTPS website origin.
- [ ] Run the checks and `pnpm build` after setting that origin. Do not deploy the supplied local-preview build unchanged as the final production-domain build.
- [ ] Upload every file/folder in `dist/public/`, or use the verified portable Node start command. Keep the `manus-storage`, `fonts`, and `assets` directories intact.
- [ ] Configure your host's directory indexes, extensionless-page behavior, custom `/404.html`, domain DNS, and HTTPS. Host at the domain root unless a developer changes the root-relative-path configuration.
- [ ] Open all seven routes on your own domain, including mobile navigation and direct deep links.
- [ ] Confirm/activate FormSubmit for the organization's mailbox and send a non-sensitive test inquiry; confirm actual receipt.
- [ ] Confirm the existing Spotfund campaign is correct and functional. The original HTTP short link was preserved, not replaced or tested through a payment.
- [ ] Keep this complete source archive backed up; keep all future private credentials in protected server settings, not frontend variables or ZIP files.
- [ ] If you later enable the retained backend features, replace/configure their platform integrations and test them separately before exposing them publicly.

## Fresh extracted-copy verification

The packaged project was extracted into a new folder and installed with `pnpm install --frozen-lockfile`. `pnpm build` then succeeded in that fresh folder with `VITE_SITE_URL=https://independent-host.example` and no Manus credentials. The generated Contact HTML, social-image metadata, and browser bundle all used the independent example origin. This confirms the source ZIP includes the required configuration, dependency patch, lockfile, assets, and build inputs. The example domain is a test value only; the delivered build remains configured for local preview until you set your real domain and rebuild. See `verification/fresh-extraction-results.json` and the fresh install/build logs.
