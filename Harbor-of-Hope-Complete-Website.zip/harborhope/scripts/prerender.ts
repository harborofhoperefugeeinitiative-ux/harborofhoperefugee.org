import "dotenv/config";
import fs from "node:fs/promises";
import path from "node:path";
import { routes } from "../client/src/content";
import { fillDocument } from "../client/src/entry-server";

const output = path.resolve("dist/public");
const template = await fs.readFile(path.join(output, "index.html"), "utf8");
for (const route of routes) {
  const destination =
    route.path === "/" ? output : path.join(output, route.path.slice(1));
  await fs.mkdir(destination, { recursive: true });
  const result = fillDocument(template, route.path);
  await fs.writeFile(path.join(destination, "index.html"), result.html);
  console.log(`Rendered ${route.path}: ${result.status}`);
}
await fs.writeFile(
  path.join(output, "404.html"),
  fillDocument(template, "/not-found").html
);

// Retained in the source backup for completeness, but not needed for hosting.
await fs.rm(path.join(output, "__manus__"), { recursive: true, force: true });
