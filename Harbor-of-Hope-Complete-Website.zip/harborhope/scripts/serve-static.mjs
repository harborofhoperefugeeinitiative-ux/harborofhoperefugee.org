import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { extname, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";

// No Manus API, database, authentication provider, or third-party runtime is used.
const root = fileURLToPath(new URL("../dist/public/", import.meta.url));
const port = Number(process.env.PORT || "3000");
const host = process.env.HOST || "0.0.0.0";
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  throw new Error("PORT must be an integer between 1 and 65535.");
}
const mime = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".ico": "image/x-icon",
  ".ttf": "font/ttf",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".txt": "text/plain; charset=utf-8",
  ".pdf": "application/pdf",
};
await stat(resolve(root, "index.html")).catch(() => {
  throw new Error("Production files are missing. Run pnpm build first.");
});

const server = createServer(async (request, response) => {
  const method = request.method || "GET";
  if (!["GET", "HEAD"].includes(method)) {
    response.writeHead(405, { Allow: "GET, HEAD" });
    response.end("Method not allowed");
    return;
  }
  let pathname;
  try {
    pathname = decodeURIComponent(new URL(request.url || "/", "http://localhost").pathname);
  } catch {
    response.writeHead(400);
    response.end("Invalid URL");
    return;
  }
  if (pathname === "/api/health") {
    response.writeHead(200, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
    response.end(method === "HEAD" ? undefined : '{"status":"ok"}');
    return;
  }
  const pieces = pathname.split("/");
  const candidate = resolve(root, "." + pathname);
  if (pieces.some(piece => piece.startsWith(".") || piece.includes("\\")) || pathname.includes("\0") || (candidate !== resolve(root) && !candidate.startsWith(resolve(root) + sep))) {
    response.writeHead(403);
    response.end("Forbidden");
    return;
  }
  try {
    const details = await stat(candidate);
    const file = details.isDirectory() ? resolve(candidate, "index.html") : candidate;
    const bytes = await readFile(file);
    const extension = extname(file).toLowerCase();
    response.writeHead(200, {
      "Content-Type": mime[extension] || "application/octet-stream",
      "Content-Length": bytes.length,
      "Cache-Control": extension === ".html" ? "no-cache" : "public, max-age=3600",
      "X-Content-Type-Options": "nosniff",
    });
    response.end(method === "HEAD" ? undefined : bytes);
  } catch (error) {
    if (!["ENOENT", "ENOTDIR", "EISDIR"].includes(error.code)) {
      console.error("Static response failed:", error.message);
      response.writeHead(500);
      response.end("Internal server error");
      return;
    }
    if (extname(pathname) || pathname.startsWith("/api/")) {
      response.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      response.end(method === "HEAD" ? undefined : "Not found");
      return;
    }
    try {
      const bytes = await readFile(resolve(root, "404.html"));
      response.writeHead(404, { "Content-Type": "text/html; charset=utf-8", "Content-Length": bytes.length });
      response.end(method === "HEAD" ? undefined : bytes);
    } catch {
      response.writeHead(404);
      response.end(method === "HEAD" ? undefined : "Not found");
    }
  }
});
server.on("error", error => { console.error(error.message); process.exit(1); });
server.listen(port, host, () => console.log(`Harbor of Hope production server listening on ${host}:${port}`));
for (const signal of ["SIGINT", "SIGTERM"]) {
  process.on(signal, () => server.close(() => process.exit(0)));
}
