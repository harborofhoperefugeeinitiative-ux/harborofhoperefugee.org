// The public website does not need this optional original template backend.
process.env.NODE_ENV = "production";
await import("../dist/index.js");
