# Harbor of Hope — complete portable website

This is a complete source export of **Harbor of Hope Refugee Support Initiative**, based on the latest saved website commit `926faa8e407d4e404ce067c5a37ac5c13a1b59fd`, dated 22 October 2026. It includes the latest homepage illustration and larger tagline. Those last changes were saved but not yet published in the original task. This export did not change or publish your live website.

Your page content, layout, colors, fonts, responsive rules, and animations were preserved. Small hosting-compatibility changes are listed in [`migration/EXPORT-CHANGES.md`](migration/EXPORT-CHANGES.md). An untouched copy of all 181 original checked-in source files is also included in [`migration/original-source.zip`](migration/original-source.zip).

## What is included

| Folder or file | Contents |
| --- | --- |
| `client/src/` | All React/TypeScript source, public pages, headers/footers, form components, styles, icons, utilities, and original tests. Unused template components are retained too. |
| `client/public/` | Local fonts and licenses, favicon, app icon, route manifest, and all 17 existing website image assets under `manus-storage/`. |
| `server/`, `shared/`, `drizzle/` | Complete original backend helpers, shared types, database schema, and SQL migrations. These are not required for the current public static website. |
| `scripts/` | Page prerendering, portable production static server, and optional original-backend startup wrapper. |
| `dist/public/` | A production build for local preview. Rebuild for your actual public domain before publishing. |
| Root configuration files | `package.json`, pinned pnpm lockfile/workspace policy, TypeScript, Vite, Vitest, formatting, dependency patch, Dockerfile, and `.env.example`. |
| `migration/` | Original snapshot, asset sources/checksums, compatibility-change record, backend-service notes, verification results, and file inventory. |

The public pages are `/`, `/about`, `/programs`, `/partner`, `/get-support`, `/contact`, and `/privacy`. The built `404.html` handles unknown pages. Every public route is prerendered, so the page text is available before JavaScript runs.

No real secret keys, private environment files, database contents, browser sessions, Git credentials, or installed `node_modules` directory are included. Dependencies are recreated from the lockfile; you do not need a Manus account for the portable public website.

## 1. Install tools and dependencies

Install **Node.js 22 LTS** (verification uses Node 22.13.0). Open a terminal in the extracted `harborhope` folder. Use the pinned **pnpm 10.18.0**:

```sh
corepack enable
corepack prepare pnpm@10.18.0 --activate
pnpm install --frozen-lockfile
```

If your Node installation does not include Corepack, install the pinned package manager instead:

```sh
npm install --global pnpm@10.18.0
pnpm install --frozen-lockfile
```

Use pnpm, not a newly generated npm lockfile. The workspace file includes the required package build-script permissions and the existing Wouter patch. A fresh machine needs internet access to download dependencies. Do not ignore installation/build failures.

## 2. Configure your website address

Copy `.env.example` to a file named `.env` in the project root. On Linux/macOS:

```sh
cp .env.example .env
```

In Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

For local testing, keep:

```dotenv
VITE_SITE_URL=http://localhost:3000
```

Before a production build, replace it with the real **HTTPS origin** of your own website, for example:

```dotenv
VITE_SITE_URL=https://www.your-domain.org
```

Use your actual domain, not the example. Do not include a path, login credentials, query string, or fragment. The site is configured for hosting at the domain root, not under a subfolder. This setting controls the initial/no-JavaScript contact form source URL and absolute social-preview image URL. It does not change visible organization information. Changing it requires rebuilding; setting it only after the build does not rewrite already generated HTML or JavaScript.

`VITE_SITE_URL` is public. **Never put passwords, API secret keys, or private database URLs into any `VITE_*` variable.** The current public site requires no private API keys or database service.

## 3. Run and edit locally

```sh
pnpm dev
```

Open `http://localhost:3000`. The development command uses port 3000 and fails rather than silently choosing a different port. To intentionally use another local port, run `pnpm dev --port 3001` and change your local `VITE_SITE_URL` to match. Do not publish the Vite development server as your production website.

Existing content is primarily in `client/src/content.ts`, public page components in `client/src/pages/harbor/`, and header/footer/form components in `client/src/components/harbor/`. CSS is in `client/src/index.css` and `client/src/styles/`. Images and fonts are under `client/public/`. You can edit and back up this copy independently; no redesign was performed in this export.

## 4. Check and build for production

```sh
pnpm check
pnpm test
pnpm build
```

`pnpm check` checks TypeScript. `pnpm test` runs the retained automated tests. `pnpm build` creates `dist/public/`, including an HTML page for every public route, CSS/JavaScript bundles, all images, icons, fonts, and `404.html`. The build does not require Manus credentials.

The historical `manus-storage` asset directory name is retained to preserve all image URLs. It is an ordinary local directory in this export, not a platform storage API. Upload it exactly as included.

## 5. Preview the production build

```sh
pnpm start
```

Open `http://localhost:3000`. The production command uses a small Node static server, accepts `PORT` and `HOST` environment variables, and exposes `/api/health`. It returns real 404s for unknown pages and missing assets instead of masking them with the homepage. This command does not enable the original template login/API backend.

Do not double-click `index.html` and use a `file://` address. The site uses root-relative paths and must be served over HTTP or HTTPS.

## 6. Publish using your own host

### Option A — static or shared hosting

Set `VITE_SITE_URL` to your real HTTPS domain, run `pnpm build`, and upload **the contents of `dist/public/`** into the host's web root (often `public_html` or `www`). `index.html` belongs directly in that web root, not inside an additional `dist/public` folder. Include `assets/`, `fonts/`, `manus-storage/`, icons, and the subfolders containing each page's `index.html`.

Use a host that serves directory `index.html` files for extensionless routes. `/about` should serve `about/index.html`. Configure its custom 404 document as `/404.html`. A blanket SPA rewrite is unnecessary because all real pages have their own HTML. Missing image/JavaScript files must remain 404s. Keep directory-index behavior enabled and avoid host-level routes that intercept the local `manus-storage` folder.

Connect the domain using your host's DNS instructions and enable HTTPS. Exact DNS records depend on the host. This export did not change DNS or deploy to a third-party host.

### Option B — a Git-based static host

Create your own repository from the extracted project, excluding `.env`, `node_modules`, caches, and private files. In the host's dashboard, select Node 22, set the public build variable `VITE_SITE_URL` to your real origin, use this build command, and set the publish/output directory to `dist/public`:

```sh
corepack enable && corepack prepare pnpm@10.18.0 --activate && pnpm install --frozen-lockfile && pnpm build
```

Use your provider's custom-404 and directory-index settings. Provider-specific deployment was not performed or verified; the generated public files are independent of the provider.

### Option C — your own Node server

Install from the lockfile, configure `.env` for the build, run `pnpm build`, and set the host's production start command to `pnpm start`. Supply its assigned `PORT` at runtime. Put the app behind an HTTPS reverse proxy, keep it running using the host's process-management tools, and store backups outside the deployed runtime. This website stores no database records or uploaded user files on the server.

### Optional Docker deployment

Supply the public origin when building the included Dockerfile:

```sh
docker build --build-arg VITE_SITE_URL=https://www.your-domain.org -t harborhope .
docker run --rm -p 3000:3000 harborhope
```

Replace the example domain before production. Private environment files and migration/backup records are excluded from the image. The Docker image was not built in this environment; the underlying pnpm build and Node runtime are verified separately.

## 7. Contact, donations, and original backend

The Contact form still sends to **FormSubmit**, addressed to `harborofhoperefugeeinitiative@gmail.com`. The receiving email must be activated through FormSubmit's confirmation email. There is no independent mail server or website database storing submissions. After deployment, send a non-sensitive test message and confirm inbox delivery. No real form submission was sent during export verification.

Donation buttons still open the supplied **Spotfund** campaign in a new tab. No card/payment data is collected here. The campaign URL was preserved exactly; availability, payout configuration, and checkout/payment success were not verified or changed. Confirm the campaign is still correct before publishing.

The original backend, database schema, and platform helpers are included for completeness, but the seven public pages do not use them. You can publish the static output without deploying those files. Read [`migration/BACKEND-SERVICES.md`](migration/BACKEND-SERVICES.md) before using `pnpm build:backend` / `pnpm start:backend` or adding login, uploads, AI, database features, or payments. Dormant Manus-dependent APIs require those services or replacement providers; source inclusion is not proof of working integrations outside Manus.

## Verification and pre-publication checklist

See [`migration/VERIFICATION.md`](migration/VERIFICATION.md) for actual checks, results, warnings, and untested operations. Logs are in `migration/verification/`. File inventory/checksums in `migration/FILE-MANIFEST.json` help check your downloaded copy.

- [ ] Set your actual HTTPS `VITE_SITE_URL` and rebuild.
- [ ] Upload the complete `dist/public/` contents or configure the Node start command.
- [ ] Configure domain DNS, HTTPS, directory indexes, and custom 404 behavior.
- [ ] Verify all seven pages and images on your own host, including mobile navigation.
- [ ] Activate/confirm FormSubmit delivery with a non-sensitive test message.
- [ ] Verify the external donation campaign and its provider settings.
- [ ] Keep private credentials out of frontend variables, source repositories, and backup archives.
- [ ] Configure and separately test any optional backend integrations you later choose to use.

Keep this complete source ZIP as your backup. Updating the public site does not require sending the original-source backup or migration verification records to a static host; upload only the generated public website output.
